/**
 * EasyService — Application principale
 * React (Web MVP) — adaptable React Native
 * Marché : Côte d'Ivoire · Abidjan
 */
import { useState, useEffect, useCallback, createContext, useContext, useRef } from "react";

// ═══════════════════════════════════════════════════════
//  DESIGN TOKENS
// ═══════════════════════════════════════════════════════
const T = {
  primary:   "#1A56DB",   // Bleu professionnel
  secondary: "#F97316",   // Orange ivoirien
  success:   "#059669",
  danger:    "#DC2626",
  warning:   "#F59E0B",
  dark:      "#111827",
  gray:      "#6B7280",
  light:     "#F9FAFB",
  border:    "#E5E7EB",
  white:     "#FFFFFF",
  card:      "#FFFFFF",
  bg:        "#F3F4F6",
  gradient1: "linear-gradient(135deg,#1A56DB,#3B82F6)",
  gradient2: "linear-gradient(135deg,#F97316,#FB923C)",
  shadow:    "0 4px 20px rgba(0,0,0,0.10)",
  shadowLg:  "0 8px 32px rgba(0,0,0,0.16)",
  radius:    14,
  radiusLg:  20,
};

// ═══════════════════════════════════════════════════════
//  APP CONTEXT
// ═══════════════════════════════════════════════════════
const AppCtx = createContext(null);
const useApp = () => useContext(AppCtx);

// ═══════════════════════════════════════════════════════
//  STATIC DATA
// ═══════════════════════════════════════════════════════
const QUARTIERS = ["Cocody","Deux-Plateaux","Yopougon","Marcory","Plateau","Abobo","Adjamé","Koumassi","Port-Bouët","Treichville","Bingerville"];

const CATEGORIES = [
  { id:"plomberie",    label:"Plomberie",       icon:"🔧", group:"Technique",  color:"#2563EB", photo:"https://images.unsplash.com/photo-1607472586893-edb57bdc0e39?w=600&q=80" },
  { id:"electricite",  label:"Électricité",     icon:"⚡", group:"Technique",  color:"#D97706", photo:"https://images.unsplash.com/photo-1621905251918-48416bd8575a?w=600&q=80" },
  { id:"menuiserie",   label:"Menuiserie",      icon:"🪵", group:"Technique",  color:"#92400E", photo:"https://images.unsplash.com/photo-1504307651254-35680f356dfd?w=600&q=80" },
  { id:"clim",         label:"Climatisation",   icon:"❄️", group:"Technique",  color:"#0891B2", photo:"https://images.unsplash.com/photo-1585771724684-38269d6639fd?w=600&q=80" },
  { id:"electromenager",label:"Électroménager", icon:"🔌", group:"Technique",  color:"#7C3AED", photo:"https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80" },
  { id:"coiffure",     label:"Coiffure",        icon:"✂️", group:"Beauté",     color:"#DB2777", photo:"https://images.unsplash.com/photo-1560066984-138dadb4c035?w=600&q=80" },
  { id:"maquillage",   label:"Maquillage",      icon:"💄", group:"Beauté",     color:"#9D174D", photo:"https://images.unsplash.com/photo-1487412947147-5cebf100ffc2?w=600&q=80" },
  { id:"manucure",     label:"Manucure",        icon:"💅", group:"Beauté",     color:"#BE185D", photo:"https://images.unsplash.com/photo-1604654894610-df63bc536371?w=600&q=80" },
  { id:"barber",       label:"Barber",          icon:"🪒", group:"Beauté",     color:"#1D4ED8", photo:"https://images.unsplash.com/photo-1503951914875-452162b0f3f1?w=600&q=80" },
  { id:"chauffeur",    label:"Chauffeur",       icon:"🚗", group:"Transport",  color:"#0F766E", photo:"https://images.unsplash.com/photo-1449965408869-eaa3f722e40d?w=600&q=80" },
  { id:"livraison",    label:"Livraison",       icon:"📦", group:"Transport",  color:"#B45309", photo:"https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=600&q=80" },
  { id:"menage",       label:"Ménage",          icon:"🧹", group:"Maison",     color:"#059669", photo:"https://images.unsplash.com/photo-1558618666-fcd25c85cd64?w=600&q=80" },
  { id:"jardinage",    label:"Jardinage",       icon:"🌿", group:"Maison",     color:"#16A34A", photo:"https://images.unsplash.com/photo-1416879595882-3373a0480b5b?w=600&q=80" },
  { id:"babysitting",  label:"Baby-sitting",    icon:"👶", group:"Maison",     color:"#F59E0B", photo:"https://images.unsplash.com/photo-1587654780291-39c9404d746b?w=600&q=80" },
];

const CAT_GROUPS = ["Technique","Beauté","Transport","Maison"];
const getCat = id => CATEGORIES.find(c=>c.id===id);

const SERVICES_BY_CAT = {
  plomberie:     ["Débouchage canalisation","Réparation fuite","Installation robinet","Pose chauffe-eau","Détection fuite","Réparation WC"],
  electricite:   ["Installation prise","Mise aux normes","Pose climatiseur","Câblage réseau","Dépannage panne","Pose luminaire"],
  menuiserie:    ["Pose porte/fenêtre","Fabrication meuble","Réparation bois","Pose parquet","Menuiserie aluminium","Dressing sur mesure"],
  clim:          ["Installation clim","Entretien clim","Réparation clim","Recharge gaz","Nettoyage filtre","Dépannage urgent"],
  electromenager:["Réparation frigo","Réparation machine à laver","Réparation TV","Réparation micro-onde","Diagnostic appareil","Entretien électroménager"],
  coiffure:      ["Coiffure femme","Tresses africaines","Lissage","Coloration","Coupe moderne","Coiffure mariage"],
  maquillage:    ["Maquillage événement","Maquillage mariage","Maquillage naturel","Maquillage soirée","Cours maquillage","Maquillage professionnel"],
  manucure:      ["Manucure classique","Pose gel","Nail art","Pédicure","Faux ongles","Soin mains"],
  barber:        ["Coupe homme","Barbe","Dégradé","Rasage classique","Coupe enfant","Soin visage"],
  chauffeur:     ["Course en ville","Aéroport","Longue distance","Mise à disposition","Déplacement professionnel","VTC premium"],
  livraison:     ["Livraison express","Livraison courses","Transport colis","Déménagement","Coursier moto","Livraison médicaments"],
  menage:        ["Ménage domicile","Nettoyage après travaux","Entretien bureau","Nettoyage moquette","Repassage","Désinfection"],
  jardinage:     ["Tonte pelouse","Taille haies","Création jardin","Arrosage auto","Évacuation déchets","Élagage"],
  babysitting:   ["Garde enfant domicile","Sortie école","Garde nuit","Aide devoirs","Baby-sitting événement","Nounou expérimentée"],
};

const PAYMENT_METHODS = [
  { id:"wave",   name:"Wave CI",         icon:"🌊", color:"#0A3EAD", desc:"Paiement instantané" },
  { id:"orange", name:"Orange Money",    icon:"🟠", color:"#FF6600", desc:"Mobile Money Orange" },
  { id:"mtn",    name:"MTN MoMo",        icon:"💛", color:"#FFCC00", desc:"Mobile Money MTN" },
  { id:"card",   name:"Carte bancaire",  icon:"💳", color:"#1A56DB", desc:"Visa / Mastercard" },
  { id:"cash",   name:"Paiement après",  icon:"💵", color:"#059669", desc:"Payez après le service" },
];

const COMMISSION_RATE = 0.10; // 10%

// ═══════════════════════════════════════════════════════
//  LOCAL STORAGE API (→ replace with real API)
// ═══════════════════════════════════════════════════════
const DB = {
  get:  k      => { try{ return JSON.parse(localStorage.getItem(`es_${k}`)||"null"); }catch{ return null; }},
  set:  (k,v)  => localStorage.setItem(`es_${k}`, JSON.stringify(v)),
  push: (k,item)=> { const arr=DB.get(k)||[]; arr.push(item); DB.set(k,arr); return item; },
  update:(k,id,changes)=>{ const arr=DB.get(k)||[]; const i=arr.findIndex(x=>x.id===id); if(i>=0){ arr[i]={...arr[i],...changes}; DB.set(k,arr); } },
};

// ── Auth ─────────────────────────────────────────────
const AuthAPI = {
  login: async (email, password) => {
    await delay(600);
    const users = DB.get("users")||[];
    const u = users.find(x=>x.email===email && x.password===btoa(password));
    if (!u) throw new Error("Email ou mot de passe incorrect");
    const session = {...u}; delete session.password;
    DB.set("session", session);
    return session;
  },
  register: async (data) => {
    await delay(800);
    const users = DB.get("users")||[];
    if (users.find(u=>u.email===data.email)) throw new Error("Cet email est déjà utilisé");
    const user = { ...data, id:uid(), password:btoa(data.password), createdAt:now(), verified:false, active:true };
    DB.push("users", user);
    if (data.role==="provider") {
      DB.push("providers", {
        id:user.id, userId:user.id, name:data.name, phone:data.phone||"",
        category:data.category||"", quartier:data.quartier||"",
        bio:data.bio||"", prix:"", photoUrl:data.photoUrl||"",
        services:[], ratings:[], available:true, verified:false,
        earnings:0, pendingEarnings:0, completedOrders:0,
        createdAt:now()
      });
    }
    const session = {...user}; delete session.password;
    DB.set("session", session);
    return session;
  },
  logout: () => { DB.set("session", null); },
  session: () => DB.get("session"),
};

// ── Providers ────────────────────────────────────────
const ProvidersAPI = {
  list: async (filters={}) => {
    await delay(300);
    let list = DB.get("providers")||[];
    if (filters.category) list = list.filter(p=>p.category===filters.category);
    if (filters.quartier) list = list.filter(p=>p.quartier===filters.quartier);
    if (filters.search)   list = list.filter(p=>p.name.toLowerCase().includes(filters.search.toLowerCase())||p.services?.some(s=>s.toLowerCase().includes(filters.search.toLowerCase())));
    if (filters.available) list = list.filter(p=>p.available);
    return list;
  },
  get: async (id) => { await delay(200); return (DB.get("providers")||[]).find(p=>p.id===id)||null; },
  save: async (data) => { await delay(400); const list=DB.get("providers")||[]; const i=list.findIndex(p=>p.id===data.id); if(i>=0)list[i]={...list[i],...data}; else list.push(data); DB.set("providers",list); return data; },
  myProfile: async (userId) => { await delay(200); return (DB.get("providers")||[]).find(p=>p.userId===userId)||null; },
};

// ── Bookings ─────────────────────────────────────────
const BookingsAPI = {
  create: async (data) => {
    await delay(800);
    const commission = Math.round((data.amount||0)*COMMISSION_RATE);
    const booking = { ...data, id:uid(), status:"pending", commission, providerAmount:(data.amount||0)-commission, createdAt:now(), updatedAt:now() };
    DB.push("bookings", booking);
    // Update provider earnings (pending)
    const providers = DB.get("providers")||[];
    const pi = providers.findIndex(p=>p.id===data.providerId);
    if(pi>=0){ providers[pi].pendingEarnings=(providers[pi].pendingEarnings||0)+booking.providerAmount; DB.set("providers",providers); }
    return booking;
  },
  list: async (userId, role="client") => {
    await delay(300);
    const all = DB.get("bookings")||[];
    return role==="provider" ? all.filter(b=>b.providerId===userId) : all.filter(b=>b.clientId===userId);
  },
  updateStatus: async (id, status) => {
    await delay(400);
    DB.update("bookings","id"===id?id:id, { status, updatedAt:now() });
    const all = DB.get("bookings")||[];
    return all.find(b=>b.id===id);
  },
};

// ── Reviews ──────────────────────────────────────────
const ReviewsAPI = {
  add: async (providerId, rating, comment, clientName) => {
    await delay(500);
    const review = { id:uid(), providerId, rating, comment, clientName, date:now() };
    DB.push("reviews", review);
    // Update provider ratings
    const reviews = DB.get("reviews")||[];
    const provReviews = reviews.filter(r=>r.providerId===providerId);
    const avg = (provReviews.reduce((a,b)=>a+b.rating,0)/provReviews.length).toFixed(1);
    const providers=DB.get("providers")||[];
    const pi=providers.findIndex(p=>p.id===providerId);
    if(pi>=0){ providers[pi].ratings=provReviews; providers[pi].avgRating=parseFloat(avg); DB.set("providers",providers); }
    return review;
  },
  forProvider: async (providerId) => { await delay(200); return (DB.get("reviews")||[]).filter(r=>r.providerId===providerId); },
};

// ── Notifications ────────────────────────────────────
const NotifAPI = {
  list: async (userId) => { await delay(200); return (DB.get(`notifs_${userId}`)||[]); },
  add:  (userId, msg, type="info") => { DB.push(`notifs_${userId}`, {id:uid(), msg, type, read:false, date:now()}); },
  markRead: (userId, id) => {
    const list=DB.get(`notifs_${userId}`)||[];
    const i=list.findIndex(n=>n.id===id); if(i>=0){ list[i].read=true; DB.set(`notifs_${userId}`,list); }
  },
};

// Helpers
const delay = ms => new Promise(r=>setTimeout(r,ms));
const uid   = () => Math.random().toString(36).slice(2)+Date.now().toString(36);
const now   = () => new Date().toISOString();
const fmt   = d  => new Date(d).toLocaleDateString("fr-CI",{day:"numeric",month:"short",year:"numeric"});
const fmtAmt= n  => `${Number(n||0).toLocaleString("fr-CI")} FCFA`;
const avgR  = arr=> arr?.length ? (arr.reduce((a,b)=>a+(b.rating||b),0)/arr.length).toFixed(1) : null;

// ═══════════════════════════════════════════════════════
//  SHARED UI COMPONENTS
// ═══════════════════════════════════════════════════════

function Spinner({ size=32, color=T.primary }) {
  return <div style={{ display:"flex",justifyContent:"center",alignItems:"center",padding:32 }}>
    <div style={{ width:size,height:size,borderRadius:"50%",border:`3px solid ${color}33`,borderTopColor:color,animation:"spin 0.8s linear infinite" }}/>
  </div>;
}

function Toast({ items, remove }) {
  return <div style={{ position:"fixed",top:16,right:16,zIndex:9999,display:"flex",flexDirection:"column",gap:8 }}>
    {items.map(t=>(
      <div key={t.id} onClick={()=>remove(t.id)} style={{
        background:t.type==="error"?T.danger:t.type==="warning"?T.warning:t.type==="success"?T.success:T.primary,
        color:"#fff",borderRadius:12,padding:"12px 16px",fontSize:14,fontWeight:600,cursor:"pointer",
        boxShadow:T.shadowLg,maxWidth:300,animation:"slideIn 0.3s ease"
      }}>{t.msg}</div>
    ))}
  </div>;
}

function useToast() {
  const [items,setItems]=useState([]);
  const add=(msg,type="info")=>{ const id=uid(); setItems(p=>[...p,{id,msg,type}]); setTimeout(()=>setItems(p=>p.filter(x=>x.id!==id)),3500); };
  const remove=id=>setItems(p=>p.filter(x=>x.id!==id));
  return { items, add, remove, success:m=>add(m,"success"), error:m=>add(m,"error"), info:m=>add(m,"info") };
}

function Btn({ children, onClick, variant="primary", size="md", disabled=false, loading=false, full=false, style:s={} }) {
  const bg = variant==="primary"?T.gradient1:variant==="secondary"?T.gradient2:variant==="outline"?"transparent":variant==="danger"?T.danger:"transparent";
  const color = variant==="outline"?T.primary:variant==="ghost"?T.gray:"#fff";
  const border = variant==="outline"?`2px solid ${T.primary}`:"none";
  const pad = size==="sm"?"8px 16px":size==="lg"?"16px 28px":"12px 20px";
  const fs  = size==="sm"?13:size==="lg"?16:14;
  return (
    <button onClick={!disabled&&!loading?onClick:undefined} style={{
      background:bg,color,border,padding:pad,borderRadius:T.radius,fontSize:fs,fontWeight:700,
      cursor:disabled||loading?"not-allowed":"pointer",opacity:disabled?0.5:1,
      width:full?"100%":"auto",letterSpacing:0.2,transition:"all 0.15s",
      boxShadow:variant!=="ghost"&&variant!=="outline"?T.shadow:"none",...s
    }}>{loading?"⏳ Chargement...":children}</button>
  );
}

function Input({ label, type="text", value, onChange, placeholder, icon, error, required, ...rest }) {
  return (
    <div style={{ marginBottom:14 }}>
      {label && <label style={{ display:"block",fontSize:13,fontWeight:600,color:T.gray,marginBottom:5 }}>{label}{required&&<span style={{color:T.danger}}>*</span>}</label>}
      <div style={{ position:"relative" }}>
        {icon && <span style={{ position:"absolute",left:13,top:"50%",transform:"translateY(-50%)",fontSize:18,color:T.gray }}>{icon}</span>}
        <input type={type} value={value} onChange={onChange} placeholder={placeholder} {...rest} style={{
          width:"100%",padding:icon?"11px 13px 11px 40px":"11px 13px",borderRadius:T.radius,
          border:`1.5px solid ${error?T.danger:T.border}`,fontSize:14,outline:"none",fontFamily:"inherit",
          background:T.light,boxSizing:"border-box",transition:"border 0.2s"
        }} onFocus={e=>e.target.style.borderColor=T.primary} onBlur={e=>e.target.style.borderColor=error?T.danger:T.border}/>
      </div>
      {error && <p style={{ fontSize:12,color:T.danger,margin:"4px 0 0" }}>{error}</p>}
    </div>
  );
}

function Select({ label, value, onChange, options, placeholder, required }) {
  return (
    <div style={{ marginBottom:14 }}>
      {label && <label style={{ display:"block",fontSize:13,fontWeight:600,color:T.gray,marginBottom:5 }}>{label}{required&&<span style={{color:T.danger}}>*</span>}</label>}
      <select value={value} onChange={onChange} style={{ width:"100%",padding:"11px 13px",borderRadius:T.radius,border:`1.5px solid ${T.border}`,fontSize:14,outline:"none",fontFamily:"inherit",background:T.light,boxSizing:"border-box",color:value?T.dark:T.gray }}>
        {placeholder && <option value="">{placeholder}</option>}
        {options.map(o=><option key={o.value||o} value={o.value||o}>{o.label||o}</option>)}
      </select>
    </div>
  );
}

function Textarea({ label, value, onChange, placeholder, rows=3 }) {
  return (
    <div style={{ marginBottom:14 }}>
      {label && <label style={{ display:"block",fontSize:13,fontWeight:600,color:T.gray,marginBottom:5 }}>{label}</label>}
      <textarea value={value} onChange={onChange} placeholder={placeholder} rows={rows} style={{ width:"100%",padding:"11px 13px",borderRadius:T.radius,border:`1.5px solid ${T.border}`,fontSize:14,outline:"none",fontFamily:"inherit",background:T.light,boxSizing:"border-box",resize:"vertical" }} onFocus={e=>e.target.style.borderColor=T.primary} onBlur={e=>e.target.style.borderColor=T.border}/>
    </div>
  );
}

function Card({ children, style:s={}, onClick }) {
  return <div onClick={onClick} style={{ background:T.card,borderRadius:T.radiusLg,padding:16,boxShadow:T.shadow,...s,cursor:onClick?"pointer":"default" }}>{children}</div>;
}

function TopBar({ title, onBack, right, transparent=false }) {
  return (
    <div style={{ background:transparent?"transparent":`linear-gradient(135deg,#1A3A8A,${T.primary})`,padding:"14px 16px",display:"flex",alignItems:"center",gap:12,position:"sticky",top:0,zIndex:50,boxShadow:transparent?"none":"0 2px 16px rgba(0,0,0,0.15)" }}>
      {onBack && <button onClick={onBack} style={{ background:"rgba(255,255,255,0.15)",border:"none",borderRadius:10,padding:"7px 14px",color:"#fff",fontWeight:700,cursor:"pointer",fontSize:14,backdropFilter:"blur(4px)" }}>← Retour</button>}
      <h3 style={{ color:"#fff",margin:0,fontFamily:"'DM Serif Display',Georgia,serif",fontSize:19,flex:1 }}>{title}</h3>
      {right}
    </div>
  );
}

function StarDisplay({ value, count, size=13 }) {
  if (!value) return <span style={{ fontSize:size,color:T.gray }}>Pas encore noté</span>;
  return (
    <div style={{ display:"flex",alignItems:"center",gap:4 }}>
      {[1,2,3,4,5].map(s=><span key={s} style={{ fontSize:size,color:s<=Math.round(value)?T.warning:"#D1D5DB" }}>★</span>)}
      <span style={{ fontSize:size,fontWeight:700,color:T.warning }}>{value}</span>
      {count!=null&&<span style={{ fontSize:size-1,color:T.gray }}>({count})</span>}
    </div>
  );
}

function StarPicker({ value, onChange }) {
  const [hover,setHover]=useState(0);
  return (
    <div style={{ display:"flex",gap:6 }}>
      {[1,2,3,4,5].map(s=>(
        <span key={s} onClick={()=>onChange(s)} onMouseEnter={()=>setHover(s)} onMouseLeave={()=>setHover(0)}
          style={{ fontSize:36,cursor:"pointer",color:s<=(hover||value)?T.warning:"#D1D5DB",transition:"transform 0.1s",display:"inline-block",transform:s<=(hover||value)?"scale(1.2)":"scale(1)" }}>★</span>
      ))}
    </div>
  );
}

function Badge({ text, color=T.primary, bg }) {
  return <span style={{ background:bg||color+"22",color,borderRadius:8,padding:"3px 10px",fontSize:12,fontWeight:700 }}>{text}</span>;
}

function BottomNav({ screen, role, navigate }) {
  const clientTabs = [
    {id:"home",icon:"🏠",label:"Accueil"},
    {id:"bookings",icon:"📅",label:"Réservations"},
    {id:"notifications",icon:"🔔",label:"Notifs"},
    {id:"profile",icon:"👤",label:"Profil"},
  ];
  const provTabs = [
    {id:"home",icon:"🏠",label:"Accueil"},
    {id:"orders",icon:"📋",label:"Missions"},
    {id:"dashboard",icon:"📊",label:"Dashboard"},
    {id:"profile",icon:"👤",label:"Profil"},
  ];
  const tabs = role==="provider" ? provTabs : clientTabs;
  return (
    <div style={{ position:"fixed",bottom:0,left:"50%",transform:"translateX(-50%)",width:"100%",maxWidth:430,background:T.white,borderTop:`1px solid ${T.border}`,display:"flex",zIndex:100,boxShadow:"0 -4px 20px rgba(0,0,0,0.1)" }}>
      {tabs.map(t=>(
        <button key={t.id} onClick={()=>navigate(t.id)} style={{ flex:1,padding:"10px 4px 8px",border:"none",background:"transparent",cursor:"pointer",display:"flex",flexDirection:"column",alignItems:"center",gap:2 }}>
          <span style={{ fontSize:22 }}>{t.icon}</span>
          <span style={{ fontSize:10,fontWeight:700,color:screen===t.id?T.primary:T.gray }}>{t.label}</span>
          {screen===t.id&&<div style={{ width:20,height:3,borderRadius:2,background:T.primary }}/>}
        </button>
      ))}
    </div>
  );
}

function ProviderCard({ provider, onPress }) {
  const cat=getCat(provider.category);
  return (
    <div onClick={onPress} style={{ background:T.card,borderRadius:T.radiusLg,overflow:"hidden",boxShadow:T.shadow,cursor:"pointer",marginBottom:12,transition:"all 0.2s" }}
      onMouseEnter={e=>{e.currentTarget.style.transform="translateY(-2px)";e.currentTarget.style.boxShadow=T.shadowLg;}}
      onMouseLeave={e=>{e.currentTarget.style.transform="translateY(0)";e.currentTarget.style.boxShadow=T.shadow;}}>
      <div style={{ height:110,position:"relative",overflow:"hidden" }}>
        {provider.photoUrl
          ? <img src={provider.photoUrl} alt="" style={{ width:"100%",height:"100%",objectFit:"cover" }} onError={e=>{e.target.style.display="none";}}/>
          : <div style={{ height:"100%",background:`linear-gradient(135deg,${cat?.color}33,${cat?.color}55)`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:40 }}>{cat?.icon}</div>
        }
        <div style={{ position:"absolute",inset:0,background:"linear-gradient(to top,rgba(0,0,0,0.5),transparent)" }}/>
        <div style={{ position:"absolute",bottom:8,left:12,display:"flex",gap:6 }}>
          {provider.verified && <Badge text="✓ Vérifié" color={T.success} bg={T.success+"dd"}/>}
          {provider.available && <Badge text="● Dispo" color="#fff" bg="rgba(5,150,105,0.85)"/>}
        </div>
      </div>
      <div style={{ padding:"12px 14px" }}>
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:4 }}>
          <p style={{ margin:0,fontWeight:700,color:T.dark,fontSize:15,fontFamily:"'DM Serif Display',Georgia,serif" }}>{provider.name}</p>
          {provider.prix&&<Badge text={provider.prix} color={cat?.color}/>}
        </div>
        <p style={{ margin:"0 0 6px",fontSize:12,color:T.gray }}>📍 {provider.quartier} · {cat?.label}</p>
        <StarDisplay value={provider.avgRating} count={provider.ratings?.length}/>
        {provider.services?.length>0&&(
          <div style={{ display:"flex",flexWrap:"wrap",gap:4,marginTop:8 }}>
            {provider.services.slice(0,3).map(s=><span key={s} style={{ background:T.bg,color:T.gray,borderRadius:6,padding:"3px 8px",fontSize:11 }}>{s}</span>)}
            {provider.services.length>3&&<span style={{ background:T.bg,color:T.gray,borderRadius:6,padding:"3px 8px",fontSize:11 }}>+{provider.services.length-3}</span>}
          </div>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: SPLASH
// ═══════════════════════════════════════════════════════
function SplashScreen({ onDone }) {
  const [progress,setProgress]=useState(0);
  useEffect(()=>{
    const iv=setInterval(()=>setProgress(p=>{ if(p>=100){ clearInterval(iv); setTimeout(onDone,300); return 100; } return p+2; }),40);
    return()=>clearInterval(iv);
  },[]);
  return (
    <div style={{ height:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",background:"linear-gradient(160deg,#0A1628 0%,#1A3A8A 45%,#1A56DB 80%,#F97316 100%)",position:"relative",overflow:"hidden" }}>
      {[[240,"-8%","-8%",0.06],[180,"65%","72%",0.04],[120,"82%","-4%",0.05]].map(([s,x,y,o],i)=>(
        <div key={i} style={{ position:"absolute",width:s,height:s,borderRadius:"50%",background:"#fff",opacity:o,left:x,top:y }}/>
      ))}
      <div style={{ textAlign:"center",animation:"popIn 0.8s cubic-bezier(.17,.89,.32,1.28)",zIndex:1 }}>
        <div style={{ width:100,height:100,borderRadius:32,background:"rgba(255,255,255,0.12)",backdropFilter:"blur(12px)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:52,margin:"0 auto 24px",border:"2px solid rgba(255,255,255,0.2)",boxShadow:"0 20px 60px rgba(0,0,0,0.3)" }}>🛠️</div>
        <h1 style={{ fontFamily:"'DM Serif Display',Georgia,serif",fontSize:52,color:"#fff",margin:"0 0 8px",letterSpacing:"-1px" }}>EasyService</h1>
        <p style={{ color:"rgba(255,255,255,0.7)",fontSize:15,letterSpacing:3,textTransform:"uppercase",margin:"0 0 4px" }}>Abidjan · Côte d'Ivoire</p>
        <p style={{ color:"rgba(255,255,255,0.5)",fontSize:13,margin:0 }}>Services à domicile en toute confiance</p>
      </div>
      <div style={{ position:"absolute",bottom:60,width:"60%",background:"rgba(255,255,255,0.15)",borderRadius:6,height:4 }}>
        <div style={{ width:`${progress}%`,height:"100%",background:"#F97316",borderRadius:6,transition:"width 0.08s" }}/>
      </div>
      <p style={{ position:"absolute",bottom:32,color:"rgba(255,255,255,0.4)",fontSize:11 }}>v1.0.0 MVP · Powered by EasyService CI</p>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: ONBOARDING
// ═══════════════════════════════════════════════════════
const SLIDES = [
  { icon:"🏠", title:"Services à domicile", sub:"Trouvez un prestataire qualifié près de chez vous en quelques secondes.", color:"linear-gradient(135deg,#1A56DB,#3B82F6)" },
  { icon:"⭐", title:"Prestataires vérifiés", sub:"Tous nos prestataires sont vérifiés et notés par la communauté.", color:"linear-gradient(135deg,#F97316,#FB923C)" },
  { icon:"💳", title:"Paiement sécurisé", sub:"Wave, Orange Money, MTN MoMo — payez facilement et en toute sécurité.", color:"linear-gradient(135deg,#059669,#34D399)" },
];
function OnboardingScreen({ onDone }) {
  const [slide,setSlide]=useState(0);
  const next=()=>{ if(slide<SLIDES.length-1)setSlide(s=>s+1); else onDone(); };
  const s=SLIDES[slide];
  return (
    <div style={{ height:"100vh",display:"flex",flexDirection:"column",background:s.color,transition:"background 0.4s" }}>
      <div style={{ flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:32,textAlign:"center" }}>
        <div style={{ fontSize:96,marginBottom:32,animation:"popIn 0.5s ease" }} key={slide}>{s.icon}</div>
        <h2 style={{ fontFamily:"'DM Serif Display',Georgia,serif",fontSize:32,color:"#fff",marginBottom:16 }}>{s.title}</h2>
        <p style={{ color:"rgba(255,255,255,0.85)",fontSize:16,lineHeight:1.7,maxWidth:280 }}>{s.sub}</p>
      </div>
      <div style={{ padding:"0 32px 48px",display:"flex",flexDirection:"column",gap:16,alignItems:"center" }}>
        <div style={{ display:"flex",gap:8 }}>
          {SLIDES.map((_,i)=><div key={i} style={{ width:i===slide?28:8,height:8,borderRadius:4,background:i===slide?"#fff":"rgba(255,255,255,0.4)",transition:"width 0.3s" }}/>)}
        </div>
        <Btn onClick={next} variant="outline" size="lg" full style={{ background:"rgba(255,255,255,0.2)",color:"#fff",border:"2px solid rgba(255,255,255,0.5)",backdropFilter:"blur(8px)" }}>
          {slide<SLIDES.length-1?"Suivant →":"Commencer →"}
        </Btn>
        {slide<SLIDES.length-1&&<button onClick={onDone} style={{ background:"none",border:"none",color:"rgba(255,255,255,0.6)",cursor:"pointer",fontSize:14 }}>Passer</button>}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: AUTH
// ═══════════════════════════════════════════════════════
function AuthScreen({ onLogin }) {
  const [mode,setMode]=useState("login");
  const [role,setRole]=useState("client");
  const [loading,setLoading]=useState(false);
  const [errors,setErrors]=useState({});
  const toast=useToast();
  const [f,setF]=useState({ name:"",email:"",password:"",phone:"",category:"",quartier:"",bio:"",prix:"",photoUrl:"" });
  const set=k=>e=>setF(p=>({...p,[k]:e.target.value}));

  const validate=()=>{
    const e={};
    if(mode==="register"&&!f.name) e.name="Nom requis";
    if(!f.email||!/\S+@\S+\.\S+/.test(f.email)) e.email="Email invalide";
    if(!f.password||f.password.length<6) e.password="Minimum 6 caractères";
    if(mode==="register"&&role==="provider"&&!f.category) e.category="Catégorie requise";
    if(mode==="register"&&role==="provider"&&!f.quartier) e.quartier="Quartier requis";
    setErrors(e); return Object.keys(e).length===0;
  };

  const submit=async()=>{
    if(!validate()) return;
    setLoading(true);
    try {
      const user = mode==="login"
        ? await AuthAPI.login(f.email, f.password)
        : await AuthAPI.register({...f, role});
      onLogin(user);
    } catch(err) { toast.error(err.message); }
    setLoading(false);
  };

  return (
    <div style={{ minHeight:"100vh",background:T.bg,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:16 }}>
      <Toast items={toast.items} remove={toast.remove}/>
      <div style={{ background:T.white,borderRadius:24,padding:28,width:"100%",maxWidth:400,boxShadow:"0 12px 48px rgba(0,0,0,0.12)" }}>
        {/* Logo */}
        <div style={{ textAlign:"center",marginBottom:24 }}>
          <div style={{ width:64,height:64,borderRadius:22,background:T.gradient1,display:"flex",alignItems:"center",justifyContent:"center",fontSize:32,margin:"0 auto 12px",boxShadow:"0 8px 24px rgba(26,86,219,0.3)" }}>🛠️</div>
          <h2 style={{ fontFamily:"'DM Serif Display',Georgia,serif",color:T.dark,margin:"0 0 2px",fontSize:26 }}>EasyService</h2>
          <p style={{ color:T.gray,fontSize:12,margin:0 }}>Abidjan, Côte d'Ivoire</p>
        </div>
        {/* Role */}
        <div style={{ display:"flex",background:T.bg,borderRadius:12,padding:4,marginBottom:20 }}>
          {[["client","👤 Client"],["provider","🔨 Prestataire"]].map(([r,l])=>(
            <button key={r} onClick={()=>setRole(r)} style={{ flex:1,padding:"9px",border:"none",borderRadius:9,cursor:"pointer",fontWeight:700,fontSize:13,transition:"all 0.2s",background:role===r?T.gradient1:"transparent",color:role===r?"#fff":T.gray }}>{l}</button>
          ))}
        </div>
        {/* Mode tabs */}
        <div style={{ display:"flex",borderBottom:`2px solid ${T.bg}`,marginBottom:20 }}>
          {[["login","Connexion"],["register","Inscription"]].map(([m,l])=>(
            <button key={m} onClick={()=>setMode(m)} style={{ flex:1,padding:"9px",border:"none",background:"transparent",cursor:"pointer",fontWeight:700,fontSize:14,color:mode===m?T.primary:T.gray,borderBottom:mode===m?`3px solid ${T.primary}`:"3px solid transparent" }}>{l}</button>
          ))}
        </div>
        {/* Fields */}
        {mode==="register"&&<Input label="Nom complet" value={f.name} onChange={set("name")} icon="👤" error={errors.name} required/>}
        <Input label="Email" type="email" value={f.email} onChange={set("email")} icon="📧" error={errors.email} required/>
        <Input label="Mot de passe" type="password" value={f.password} onChange={set("password")} icon="🔒" error={errors.password} required/>
        {mode==="register"&&role==="provider"&&(<>
          <Input label="Téléphone" value={f.phone} onChange={set("phone")} icon="📞" placeholder="+225 07 XX XX XX"/>
          <Select label="Catégorie principale" value={f.category} onChange={set("category")} placeholder="Choisir une catégorie *" options={CATEGORIES.map(c=>({value:c.id,label:`${c.icon} ${c.label}`}))} required/>
          {errors.category&&<p style={{fontSize:12,color:T.danger,marginTop:-10,marginBottom:10}}>{errors.category}</p>}
          <Select label="Quartier d'intervention" value={f.quartier} onChange={set("quartier")} placeholder="Choisir votre quartier *" options={QUARTIERS} required/>
          {errors.quartier&&<p style={{fontSize:12,color:T.danger,marginTop:-10,marginBottom:10}}>{errors.quartier}</p>}
          <Input label="Tarif indicatif" value={f.prix} onChange={set("prix")} icon="💰" placeholder="ex: 5 000 – 20 000 FCFA"/>
          <Textarea label="Présentation / Bio" value={f.bio} onChange={set("bio")} placeholder="Décrivez votre expérience..."/>
        </>)}
        <Btn onClick={submit} loading={loading} full size="lg" style={{ marginTop:4 }}>
          {mode==="login"?"Se connecter →":"Créer mon compte →"}
        </Btn>
        <p style={{ textAlign:"center",fontSize:12,color:T.gray,marginTop:14,lineHeight:1.6 }}>
          En continuant, vous acceptez nos <span style={{color:T.primary,cursor:"pointer"}}>CGU</span> et notre <span style={{color:T.primary,cursor:"pointer"}}>Politique de confidentialité</span>
        </p>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: HOME
// ═══════════════════════════════════════════════════════
function HomeScreen({ navigate }) {
  const { user } = useApp();
  const [search,setSearch]=useState("");
  const [quartier,setQuartier]=useState("");
  const [providers,setProviders]=useState([]);
  const [loading,setLoading]=useState(true);
  const [urgent,setUrgent]=useState(false);

  useEffect(()=>{ ProvidersAPI.list({available:true}).then(d=>{ setProviders(d); setLoading(false); }); },[]);

  const topRated = [...providers].sort((a,b)=>(b.avgRating||0)-(a.avgRating||0)).slice(0,4);
  const newest   = [...providers].sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,3);
  const catCounts = CATEGORIES.map(c=>({ ...c, count:providers.filter(p=>p.category===c.id).length }));

  return (
    <div style={{ minHeight:"100vh",background:T.bg,paddingBottom:80 }}>
      {/* Header */}
      <div style={{ background:T.gradient1,padding:"20px 16px 44px",position:"relative",overflow:"hidden" }}>
        {[[200,"-10%","-15%",0.06],[140,"70%","65%",0.05]].map(([s,x,y,o],i)=><div key={i} style={{position:"absolute",width:s,height:s,borderRadius:"50%",background:"#fff",opacity:o,left:x,top:y}}/>)}
        <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:16,position:"relative" }}>
          <div>
            <p style={{ margin:0,color:"rgba(255,255,255,0.7)",fontSize:13 }}>Bienvenue 👋</p>
            <h2 style={{ margin:0,color:"#fff",fontFamily:"'DM Serif Display',Georgia,serif",fontSize:24 }}>{user?.name}</h2>
            <p style={{ margin:"2px 0 0",color:"rgba(255,255,255,0.65)",fontSize:12 }}>📍 {quartier||"Abidjan"}</p>
          </div>
          <div style={{ display:"flex",gap:8 }}>
            <button onClick={()=>navigate("notifications")} style={{ background:"rgba(255,255,255,0.15)",border:"none",borderRadius:10,width:40,height:40,cursor:"pointer",fontSize:18,backdropFilter:"blur(4px)" }}>🔔</button>
            <button onClick={()=>navigate("profile")} style={{ background:"rgba(255,255,255,0.15)",border:"none",borderRadius:10,width:40,height:40,cursor:"pointer",fontSize:18,backdropFilter:"blur(4px)" }}>👤</button>
          </div>
        </div>
        {/* Search */}
        <div style={{ background:"#fff",borderRadius:14,padding:"0 14px",display:"flex",alignItems:"center",gap:10,boxShadow:"0 8px 24px rgba(0,0,0,0.2)",position:"relative" }}>
          <span style={{ fontSize:18,color:T.gray }}>🔍</span>
          <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Service, prestataire, quartier..." style={{ flex:1,border:"none",outline:"none",fontSize:14,padding:"13px 0",background:"transparent",fontFamily:"inherit",color:T.dark }}/>
          {search&&<button onClick={()=>setSearch("")} style={{ background:"none",border:"none",cursor:"pointer",fontSize:16,color:T.gray }}>✕</button>}
        </div>
      </div>

      <div style={{ padding:"16px 14px",marginTop:-16 }}>
        {/* Mode urgence */}
        <div onClick={()=>setUrgent(u=>!u)} style={{ background:urgent?T.gradient2:"#fff",borderRadius:T.radiusLg,padding:"14px 16px",marginBottom:16,display:"flex",alignItems:"center",gap:14,boxShadow:T.shadow,cursor:"pointer",border:urgent?"none":`2px solid ${T.secondary}`,transition:"all 0.2s" }}>
          <div style={{ width:44,height:44,borderRadius:14,background:urgent?"rgba(255,255,255,0.2)":T.secondary+"22",display:"flex",alignItems:"center",justifyContent:"center",fontSize:24 }}>🚨</div>
          <div style={{ flex:1 }}>
            <p style={{ margin:0,fontWeight:700,color:urgent?"#fff":T.dark,fontSize:15 }}>Mode Urgence</p>
            <p style={{ margin:0,fontSize:12,color:urgent?"rgba(255,255,255,0.8)":T.gray }}>Prestataire disponible maintenant</p>
          </div>
          <div style={{ width:24,height:24,borderRadius:"50%",background:urgent?"rgba(255,255,255,0.3)":"#F3F4F6",display:"flex",alignItems:"center",justifyContent:"center" }}>
            <span style={{ fontSize:12,color:urgent?"#fff":T.gray }}>✓</span>
          </div>
        </div>

        {/* Quartier filter */}
        <div style={{ display:"flex",gap:8,overflowX:"auto",paddingBottom:4,marginBottom:16,scrollbarWidth:"none" }}>
          {["Tous",...QUARTIERS].map(q=>(
            <button key={q} onClick={()=>setQuartier(q==="Tous"?"":q)} style={{ flexShrink:0,padding:"7px 14px",borderRadius:20,border:"none",cursor:"pointer",fontWeight:600,fontSize:12,transition:"all 0.15s",background:quartier===(q==="Tous"?"":q)?T.primary:T.white,color:quartier===(q==="Tous"?"":q)?"#fff":T.gray,boxShadow:T.shadow }}>{q}</button>
          ))}
        </div>

        {/* Search results */}
        {search&&(
          <div style={{ marginBottom:20 }}>
            <h4 style={{ color:T.dark,margin:"0 0 12px",fontFamily:"'DM Serif Display',Georgia,serif",fontSize:18 }}>Résultats pour « {search} »</h4>
            {providers.filter(p=>p.name.toLowerCase().includes(search.toLowerCase())||p.services?.some(s=>s.toLowerCase().includes(search.toLowerCase()))).map(p=>(
              <ProviderCard key={p.id} provider={p} onPress={()=>navigate("detail",{provider:p})}/>
            ))}
          </div>
        )}

        {!search&&(<>
          {/* Stats */}
          <div style={{ display:"flex",gap:10,marginBottom:20 }}>
            {[{n:providers.length,l:"Prestataires",i:"🔨"},{n:CATEGORIES.length,l:"Services",i:"📋"},{n:"10+",l:"Quartiers",i:"📍"}].map(s=>(
              <div key={s.l} style={{ flex:1,background:T.white,borderRadius:14,padding:"12px 8px",textAlign:"center",boxShadow:T.shadow }}>
                <p style={{ margin:0,fontSize:20 }}>{s.i}</p>
                <p style={{ margin:"3px 0 0",fontWeight:800,fontSize:16,color:T.primary }}>{s.n}</p>
                <p style={{ margin:0,fontSize:10,color:T.gray }}>{s.l}</p>
              </div>
            ))}
          </div>

          {/* Categories — grouped */}
          {CAT_GROUPS.map(group=>{
            const cats=catCounts.filter(c=>c.group===group);
            return (
              <div key={group} style={{ marginBottom:20 }}>
                <h4 style={{ color:T.dark,margin:"0 0 12px",fontFamily:"'DM Serif Display',Georgia,serif",fontSize:17 }}>{group}</h4>
                <div style={{ display:"grid",gridTemplateColumns:"repeat(4,1fr)",gap:10 }}>
                  {cats.map(c=>(
                    <div key={c.id} onClick={()=>navigate("category",{category:c.id,quartier})}
                      style={{ background:T.white,borderRadius:T.radius,padding:"12px 6px",textAlign:"center",boxShadow:T.shadow,cursor:"pointer" }}>
                      <div style={{ fontSize:26 }}>{c.icon}</div>
                      <p style={{ margin:"5px 0 0",fontSize:11,fontWeight:600,color:T.dark,lineHeight:1.2 }}>{c.label}</p>
                      {c.count>0&&<p style={{ margin:"2px 0 0",fontSize:10,color:T.gray }}>{c.count}</p>}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}

          {topRated.length>0&&(<>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"center",marginBottom:12 }}>
              <h4 style={{ color:T.dark,margin:0,fontFamily:"'DM Serif Display',Georgia,serif",fontSize:18 }}>⭐ Mieux notés</h4>
              <span onClick={()=>navigate("allproviders")} style={{ color:T.primary,fontSize:13,fontWeight:700,cursor:"pointer" }}>Voir tout →</span>
            </div>
            {topRated.map(p=><ProviderCard key={p.id} provider={p} onPress={()=>navigate("detail",{provider:p})}/>)}
          </>)}

          {providers.length===0&&!loading&&(
            <div style={{ textAlign:"center",padding:"48px 20px" }}>
              <div style={{ fontSize:56 }}>🔍</div>
              <p style={{ color:T.gray,marginTop:12,lineHeight:1.7 }}>Aucun prestataire inscrit pour l'instant.<br/><strong style={{color:T.primary}}>Soyez le premier prestataire !</strong></p>
            </div>
          )}
          {loading&&<Spinner/>}
        </>)}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: CATEGORY (list by cat)
// ═══════════════════════════════════════════════════════
function CategoryScreen({ category, initQuartier, navigate }) {
  const cat=getCat(category);
  const [providers,setProviders]=useState([]);
  const [loading,setLoading]=useState(true);
  const [selectedSvc,setSelectedSvc]=useState(null);
  const [quartier,setQuartier]=useState(initQuartier||"");
  useEffect(()=>{ ProvidersAPI.list({category,quartier}).then(d=>{ setProviders(d); setLoading(false); }); },[category,quartier]);
  const filtered=selectedSvc?providers.filter(p=>p.services?.includes(selectedSvc)):providers;
  return (
    <div style={{ minHeight:"100vh",background:T.bg,paddingBottom:80 }}>
      <div style={{ height:180,position:"relative",overflow:"hidden" }}>
        <img src={cat?.photo} alt="" style={{ width:"100%",height:"100%",objectFit:"cover" }} onError={e=>{e.target.style.display="none";}}/>
        <div style={{ position:"absolute",inset:0,background:"linear-gradient(to top,rgba(0,0,0,0.75),rgba(0,0,0,0.15))" }}/>
        <button onClick={()=>navigate("home")} style={{ position:"absolute",top:14,left:14,background:"rgba(255,255,255,0.2)",backdropFilter:"blur(6px)",border:"none",borderRadius:10,padding:"7px 14px",color:"#fff",fontWeight:700,cursor:"pointer" }}>← Retour</button>
        <div style={{ position:"absolute",bottom:16,left:16 }}>
          <h2 style={{ color:"#fff",margin:"0 0 4px",fontFamily:"'DM Serif Display',Georgia,serif",fontSize:28 }}>{cat?.icon} {cat?.label}</h2>
          <p style={{ color:"rgba(255,255,255,0.75)",margin:0,fontSize:13 }}>{cat?.group}</p>
        </div>
      </div>
      <div style={{ padding:"14px 14px 0" }}>
        <Select value={quartier} onChange={e=>setQuartier(e.target.value)} placeholder="📍 Tous les quartiers" options={QUARTIERS}/>
        <div style={{ display:"flex",flexWrap:"wrap",gap:7,marginBottom:14 }}>
          <span onClick={()=>setSelectedSvc(null)} style={{ padding:"6px 14px",borderRadius:20,fontSize:12,fontWeight:600,cursor:"pointer",background:!selectedSvc?T.primary:T.white,color:!selectedSvc?"#fff":T.gray,boxShadow:T.shadow }}>Tous</span>
          {(SERVICES_BY_CAT[category]||[]).map(s=>(
            <span key={s} onClick={()=>setSelectedSvc(s===selectedSvc?null:s)} style={{ padding:"6px 14px",borderRadius:20,fontSize:12,fontWeight:600,cursor:"pointer",background:selectedSvc===s?T.primary:T.white,color:selectedSvc===s?"#fff":T.gray,boxShadow:T.shadow }}>{s}</span>
          ))}
        </div>
        <p style={{ fontSize:12,color:T.gray,fontWeight:600,margin:"0 0 12px" }}>{filtered.length} PRESTATAIRE(S)</p>
        {loading?<Spinner/>:filtered.length===0?<div style={{ textAlign:"center",padding:"32px 0" }}><div style={{ fontSize:40 }}>😕</div><p style={{ color:T.gray,marginTop:8 }}>Aucun prestataire disponible.</p></div>:filtered.map(p=><ProviderCard key={p.id} provider={p} onPress={()=>navigate("detail",{provider:p,from:"category",fromData:{category,initQuartier:quartier}})}/>)}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: PROVIDER DETAIL
// ═══════════════════════════════════════════════════════
function DetailScreen({ providerInit, from, fromData, navigate }) {
  const { user } = useApp();
  const toast = useToast();
  const [provider,setProvider]=useState(providerInit);
  const [tab,setTab]=useState("info");
  const [reviews,setReviews]=useState([]);
  const [rating,setRating]=useState(0);
  const [comment,setComment]=useState("");
  const [rated,setRated]=useState(false);
  const cat=getCat(provider.category);

  useEffect(()=>{ ReviewsAPI.forProvider(provider.id).then(setReviews); },[provider.id]);

  const goBack=()=>from?navigate(from,fromData):navigate("home");

  const handleReview=async()=>{
    if(!rating){ toast.error("Choisissez une note"); return; }
    await ReviewsAPI.add(provider.id,rating,comment,user?.name||"Anonyme");
    const updated=await ProvidersAPI.get(provider.id);
    if(updated){ setProvider(updated); }
    const r=await ReviewsAPI.forProvider(provider.id); setReviews(r);
    setRated(true); toast.success("Avis enregistré !");
  };

  return (
    <div style={{ minHeight:"100vh",background:T.bg,paddingBottom:80 }}>
      <Toast items={toast.items} remove={toast.remove}/>
      {/* Hero */}
      <div style={{ height:220,position:"relative",overflow:"hidden" }}>
        {provider.photoUrl?<img src={provider.photoUrl} alt="" style={{ width:"100%",height:"100%",objectFit:"cover" }}/>:<div style={{ height:"100%",background:`linear-gradient(135deg,${cat?.color}44,${cat?.color}77)`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:72 }}>{cat?.icon}</div>}
        <div style={{ position:"absolute",inset:0,background:"linear-gradient(to top,rgba(0,0,0,0.75),rgba(0,0,0,0.1))" }}/>
        <button onClick={goBack} style={{ position:"absolute",top:14,left:14,background:"rgba(255,255,255,0.2)",backdropFilter:"blur(6px)",border:"none",borderRadius:10,padding:"7px 14px",color:"#fff",fontWeight:700,cursor:"pointer" }}>← Retour</button>
        {provider.verified&&<span style={{ position:"absolute",top:14,right:14,background:T.success,color:"#fff",borderRadius:8,padding:"4px 12px",fontSize:12,fontWeight:700 }}>✓ Vérifié</span>}
        <div style={{ position:"absolute",bottom:16,left:16 }}>
          <h2 style={{ color:"#fff",margin:"0 0 4px",fontFamily:"'DM Serif Display',Georgia,serif",fontSize:24 }}>{provider.name}</h2>
          <p style={{ color:"rgba(255,255,255,0.8)",margin:0,fontSize:13 }}>📍 {provider.quartier} · {cat?.label}</p>
        </div>
      </div>
      {/* Quick stats */}
      <div style={{ display:"flex",background:T.white,borderBottom:`1px solid ${T.bg}` }}>
        {[{v:provider.avgRating||"–",l:"Note"},{v:reviews.length,l:"Avis"},{v:provider.available?"✓":"✗",l:"Dispo"},{v:provider.completedOrders||0,l:"Missions"}].map(s=>(
          <div key={s.l} style={{ flex:1,padding:"12px 8px",textAlign:"center",borderRight:`1px solid ${T.bg}` }}>
            <p style={{ margin:0,fontSize:18,fontWeight:800,color:T.primary }}>{s.v}</p>
            <p style={{ margin:0,fontSize:11,color:T.gray }}>{s.l}</p>
          </div>
        ))}
      </div>
      {/* Tabs */}
      <div style={{ display:"flex",background:T.white,borderBottom:`2px solid ${T.bg}`,position:"sticky",top:0,zIndex:10 }}>
        {[["info","📋 Info"],["book","📅 Réserver"],["avis","⭐ Avis"]].map(([t,l])=>(
          <button key={t} onClick={()=>setTab(t)} style={{ flex:1,padding:"12px",border:"none",background:"transparent",cursor:"pointer",fontWeight:700,fontSize:13,color:tab===t?T.primary:T.gray,borderBottom:tab===t?`3px solid ${T.primary}`:"3px solid transparent" }}>{l}</button>
        ))}
      </div>
      <div style={{ padding:16 }}>
        {/* INFO */}
        {tab==="info"&&(<>
          {provider.bio&&<Card style={{ marginBottom:14 }}><h4 style={{ margin:"0 0 8px",color:T.primary }}>À propos</h4><p style={{ margin:0,color:T.gray,lineHeight:1.75,fontSize:14 }}>{provider.bio}</p></Card>}
          <Card style={{ marginBottom:14 }}>
            <h4 style={{ margin:"0 0 12px",color:T.primary }}>Informations</h4>
            {[["📞","Téléphone",provider.phone||"Non renseigné"],["💰","Tarif",provider.prix||"Sur devis"],["📍","Zone",provider.quartier],["🗓️","Membre depuis",fmt(provider.createdAt)]].map(([i,k,v])=>(
              <div key={k} style={{ display:"flex",justifyContent:"space-between",padding:"9px 0",borderBottom:`1px solid ${T.bg}` }}>
                <span style={{ fontSize:14,color:T.gray }}>{i} {k}</span>
                <span style={{ fontSize:14,fontWeight:600,color:T.dark }}>{v}</span>
              </div>
            ))}
          </Card>
          {provider.services?.length>0&&<Card><h4 style={{ margin:"0 0 12px",color:T.primary }}>Services proposés</h4><div style={{ display:"flex",flexWrap:"wrap",gap:8 }}>{provider.services.map(s=><span key={s} style={{ background:cat?.color+"22",color:cat?.color,borderRadius:8,padding:"6px 12px",fontSize:13,fontWeight:600 }}>{s}</span>)}</div></Card>}
        </>)}
        {/* BOOK */}
        {tab==="book"&&<BookingForm provider={provider} navigate={navigate} toast={toast}/>}
        {/* AVIS */}
        {tab==="avis"&&(<>
          {reviews.length>0&&<Card style={{ marginBottom:14 }}>
            <div style={{ display:"flex",gap:16,alignItems:"center",marginBottom:16 }}>
              <div style={{ textAlign:"center" }}>
                <p style={{ margin:0,fontSize:40,fontWeight:800,color:T.warning,fontFamily:"'DM Serif Display',Georgia,serif" }}>{provider.avgRating||"–"}</p>
                <StarDisplay value={provider.avgRating} size={16}/>
                <p style={{ margin:"4px 0 0",fontSize:12,color:T.gray }}>{reviews.length} avis</p>
              </div>
              <div style={{ flex:1 }}>
                {[5,4,3,2,1].map(s=>{
                  const cnt=reviews.filter(r=>r.rating===s).length;
                  const pct=reviews.length?(cnt/reviews.length)*100:0;
                  return <div key={s} style={{ display:"flex",alignItems:"center",gap:6,marginBottom:4 }}>
                    <span style={{ fontSize:11,color:T.gray,width:8 }}>{s}</span>
                    <div style={{ flex:1,height:6,background:"#E5E7EB",borderRadius:3 }}><div style={{ width:`${pct}%`,height:"100%",background:T.warning,borderRadius:3,transition:"width 0.5s" }}/></div>
                    <span style={{ fontSize:11,color:T.gray,width:16 }}>{cnt}</span>
                  </div>;
                })}
              </div>
            </div>
            {[...reviews].reverse().map((r,i)=>(
              <div key={r.id} style={{ padding:"12px 0",borderBottom:i<reviews.length-1?`1px solid ${T.bg}`:"none" }}>
                <div style={{ display:"flex",alignItems:"center",gap:10,marginBottom:6 }}>
                  <div style={{ width:36,height:36,borderRadius:10,background:T.bg,display:"flex",alignItems:"center",justifyContent:"center",fontSize:16 }}>👤</div>
                  <div><p style={{ margin:0,fontWeight:600,fontSize:14,color:T.dark }}>{r.clientName}</p><p style={{ margin:0,fontSize:11,color:T.gray }}>{fmt(r.date)}</p></div>
                  <div style={{ marginLeft:"auto" }}><StarDisplay value={r.rating} size={13}/></div>
                </div>
                {r.comment&&<p style={{ margin:"0 0 0 46px",fontSize:13,color:T.gray,fontStyle:"italic" }}>"{r.comment}"</p>}
              </div>
            ))}
          </Card>}
          <Card>
            <h4 style={{ margin:"0 0 14px",color:T.primary }}>Laisser un avis</h4>
            {rated?<p style={{ color:T.success,fontWeight:700 }}>✅ Avis enregistré, merci !</p>:(<>
              <StarPicker value={rating} onChange={setRating}/>
              <Textarea value={comment} onChange={e=>setComment(e.target.value)} placeholder="Partagez votre expérience..." style={{ marginTop:12 }}/>
              <Btn onClick={handleReview} disabled={!rating}>Soumettre l'avis</Btn>
            </>)}
          </Card>
        </>)}
      </div>
    </div>
  );
}

// ─── Booking Form (sub-component) ────────────────────
function BookingForm({ provider, navigate, toast }) {
  const { user } = useApp();
  const cat=getCat(provider.category);
  const [svc,setSvc]=useState("");
  const [date,setDate]=useState("");
  const [time,setTime]=useState("");
  const [note,setNote]=useState("");
  const [pay,setPay]=useState("");
  const [amount,setAmount]=useState("");
  const [done,setDone]=useState(false);
  const [loading,setLoading]=useState(false);

  const submit=async()=>{
    if(!svc||!date||!pay){ toast.error("Veuillez remplir tous les champs obligatoires"); return; }
    setLoading(true);
    try {
      const booking=await BookingsAPI.create({ clientId:user.id, clientName:user.name, providerId:provider.id, providerName:provider.name, providerCategory:provider.category, service:svc, date, time, note, payMethod:pay, amount:parseInt(amount)||0, quartier:provider.quartier });
      NotifAPI.add(provider.userId||provider.id, `Nouvelle réservation de ${user.name} : ${svc}`, "booking");
      setDone(true); toast.success("Réservation confirmée ! 🎉");
    } catch(e){ toast.error(e.message); }
    setLoading(false);
  };

  if(done) return (
    <Card style={{ textAlign:"center",padding:"32px 16px" }}>
      <div style={{ fontSize:64 }}>🎉</div>
      <h3 style={{ color:T.success,fontFamily:"'DM Serif Display',Georgia,serif",margin:"12px 0 6px" }}>Réservation confirmée !</h3>
      <p style={{ color:T.gray,fontSize:14,marginBottom:16 }}>{provider.name} sera notifié et vous contactera sous peu.</p>
      <Btn onClick={()=>navigate("bookings")} variant="secondary">Voir mes réservations</Btn>
    </Card>
  );

  return (
    <Card>
      <h4 style={{ margin:"0 0 16px",color:T.primary }}>Détails de la réservation</h4>
      <Select label="Service souhaité" value={svc} onChange={e=>setSvc(e.target.value)} placeholder="Choisir un service *" options={provider.services?.length?provider.services:(SERVICES_BY_CAT[provider.category]||[])} required/>
      <Input label="Date souhaitée" type="date" value={date} onChange={e=>setDate(e.target.value)} required/>
      <Input label="Heure préférée" type="time" value={time} onChange={e=>setTime(e.target.value)}/>
      <Input label="Montant estimé (FCFA)" type="number" value={amount} onChange={e=>setAmount(e.target.value)} icon="💰" placeholder="ex: 15000"/>
      <Textarea label="Note pour le prestataire" value={note} onChange={e=>setNote(e.target.value)} placeholder="Décrivez votre besoin précisément..."/>
      <h4 style={{ margin:"0 0 12px",color:T.primary }}>Mode de paiement *</h4>
      <div style={{ background:"#FFFBEB",border:`1px solid ${T.warning}`,borderRadius:10,padding:"9px 12px",fontSize:13,color:"#92400E",marginBottom:12 }}>💡 Paiement simulé — Intégration Wave/Orange Money en cours</div>
      {PAYMENT_METHODS.map(m=>(
        <div key={m.id} onClick={()=>setPay(m.id)} style={{ display:"flex",alignItems:"center",gap:12,padding:"13px 14px",borderRadius:T.radius,border:`2px solid ${pay===m.id?m.color:T.border}`,marginBottom:10,cursor:"pointer",background:pay===m.id?m.color+"11":"#fff",transition:"all 0.15s" }}>
          <div style={{ width:20,height:20,borderRadius:"50%",border:`2px solid ${pay===m.id?m.color:"#D1D5DB"}`,background:pay===m.id?m.color:"#fff",transition:"all 0.2s" }}/>
          <span style={{ fontSize:22 }}>{m.icon}</span>
          <div style={{ flex:1 }}><p style={{ margin:0,fontWeight:700,color:T.dark,fontSize:14 }}>{m.name}</p><p style={{ margin:0,fontSize:11,color:T.gray }}>{m.desc}</p></div>
          {amount&&pay===m.id&&<div style={{ textAlign:"right" }}><p style={{ margin:0,fontSize:13,fontWeight:700,color:m.color }}>{fmtAmt(amount)}</p><p style={{ margin:0,fontSize:10,color:T.gray }}>Commission: {fmtAmt(Math.round(amount*COMMISSION_RATE))}</p></div>}
        </div>
      ))}
      <Btn onClick={submit} loading={loading} full size="lg" variant="secondary" style={{ marginTop:8 }}>Confirmer la réservation →</Btn>
    </Card>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: BOOKINGS (client)
// ═══════════════════════════════════════════════════════
const STATUS_COLORS = { pending:T.warning, confirmed:T.success, completed:T.primary, cancelled:T.danger, rejected:"#9CA3AF" };
const STATUS_LABELS = { pending:"En attente",confirmed:"Confirmé",completed:"Terminé",cancelled:"Annulé",rejected:"Refusé" };

function BookingsScreen({ navigate }) {
  const { user } = useApp();
  const [bookings,setBookings]=useState([]);
  const [loading,setLoading]=useState(true);
  const [filter,setFilter]=useState("all");

  useEffect(()=>{ BookingsAPI.list(user.id,"client").then(d=>{ setBookings(d.reverse()); setLoading(false); }); },[]);

  const filtered=filter==="all"?bookings:bookings.filter(b=>b.status===filter);

  return (
    <div style={{ minHeight:"100vh",background:T.bg,paddingBottom:80 }}>
      <TopBar title="Mes réservations"/>
      <div style={{ padding:"12px 14px" }}>
        {/* Filter tabs */}
        <div style={{ display:"flex",gap:6,overflowX:"auto",marginBottom:16,scrollbarWidth:"none" }}>
          {[["all","Toutes"],["pending","En attente"],["confirmed","Confirmées"],["completed","Terminées"],["cancelled","Annulées"]].map(([v,l])=>(
            <button key={v} onClick={()=>setFilter(v)} style={{ flexShrink:0,padding:"7px 14px",borderRadius:20,border:"none",cursor:"pointer",fontWeight:600,fontSize:12,background:filter===v?T.primary:T.white,color:filter===v?"#fff":T.gray,boxShadow:T.shadow }}>{l}</button>
          ))}
        </div>
        {loading?<Spinner/>:filtered.length===0?(
          <div style={{ textAlign:"center",padding:"48px 16px" }}>
            <div style={{ fontSize:52 }}>📅</div>
            <p style={{ color:T.gray,marginTop:12 }}>Aucune réservation.</p>
            <Btn onClick={()=>navigate("home")} style={{ marginTop:16 }}>Trouver un prestataire</Btn>
          </div>
        ):filtered.map(b=>(
          <Card key={b.id} style={{ marginBottom:12 }}>
            <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:10 }}>
              <div>
                <p style={{ margin:"0 0 3px",fontWeight:700,color:T.dark,fontSize:15 }}>{b.service}</p>
                <p style={{ margin:0,fontSize:13,color:T.gray }}>👤 {b.providerName}</p>
              </div>
              <span style={{ background:STATUS_COLORS[b.status]+"22",color:STATUS_COLORS[b.status],borderRadius:8,padding:"4px 10px",fontSize:12,fontWeight:700 }}>{STATUS_LABELS[b.status]||b.status}</span>
            </div>
            <div style={{ display:"flex",flexWrap:"wrap",gap:10,marginBottom:b.note?10:0 }}>
              <span style={{ fontSize:12,color:T.gray }}>📅 {fmt(b.date)}{b.time&&" à "+b.time}</span>
              <span style={{ fontSize:12,color:T.gray }}>💳 {PAYMENT_METHODS.find(m=>m.id===b.payMethod)?.name||b.payMethod}</span>
              {b.amount>0&&<span style={{ fontSize:12,color:T.gray }}>💰 {fmtAmt(b.amount)}</span>}
            </div>
            {b.note&&<p style={{ margin:0,fontSize:12,color:T.gray,fontStyle:"italic",borderTop:`1px solid ${T.bg}`,paddingTop:8 }}>{b.note}</p>}
          </Card>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: NOTIFICATIONS
// ═══════════════════════════════════════════════════════
function NotificationsScreen({ navigate }) {
  const { user } = useApp();
  const [notifs,setNotifs]=useState([]);
  useEffect(()=>{ NotifAPI.list(user.id).then(d=>setNotifs(d.reverse())); },[]);
  return (
    <div style={{ minHeight:"100vh",background:T.bg,paddingBottom:80 }}>
      <TopBar title="Notifications" onBack={()=>navigate("home")}/>
      <div style={{ padding:"12px 14px" }}>
        {notifs.length===0?<div style={{ textAlign:"center",padding:"48px 16px" }}><div style={{ fontSize:52 }}>🔔</div><p style={{ color:T.gray,marginTop:12 }}>Aucune notification.</p></div>:
        notifs.map(n=>(
          <Card key={n.id} onClick={()=>{ NotifAPI.markRead(user.id,n.id); }} style={{ marginBottom:10,opacity:n.read?0.6:1 }}>
            <div style={{ display:"flex",gap:12,alignItems:"flex-start" }}>
              <span style={{ fontSize:22 }}>{n.type==="booking"?"📅":n.type==="review"?"⭐":n.type==="payment"?"💰":"🔔"}</span>
              <div style={{ flex:1 }}>
                <p style={{ margin:"0 0 4px",fontSize:14,color:T.dark,fontWeight:n.read?400:600 }}>{n.msg}</p>
                <p style={{ margin:0,fontSize:11,color:T.gray }}>{fmt(n.date)}</p>
              </div>
              {!n.read&&<div style={{ width:8,height:8,borderRadius:"50%",background:T.primary,flexShrink:0,marginTop:6 }}/>}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: PROFILE (client)
// ═══════════════════════════════════════════════════════
function ProfileScreen({ navigate }) {
  const { user, logout } = useApp();
  const menuItems = [
    ...(user?.role==="provider"?[{icon:"📊",label:"Mon dashboard prestataire",action:()=>navigate("dashboard")}]:[]),
    {icon:"📅",label:"Mes réservations",action:()=>navigate("bookings")},
    {icon:"🔔",label:"Notifications",action:()=>navigate("notifications")},
    {icon:"❓",label:"Aide & Support",action:()=>navigate("support")},
    {icon:"📜",label:"Conditions d'utilisation",action:()=>{}},
    {icon:"🔒",label:"Confidentialité & sécurité",action:()=>{}},
    {icon:"📣",label:"Parrainer un ami",action:()=>{}},
  ];
  return (
    <div style={{ minHeight:"100vh",background:T.bg,paddingBottom:80 }}>
      {/* Hero */}
      <div style={{ background:T.gradient1,padding:"32px 16px 48px",textAlign:"center",position:"relative",overflow:"hidden" }}>
        <div style={{ position:"absolute",inset:0,opacity:0.04,backgroundImage:"radial-gradient(circle at 2px 2px, #fff 1px, transparent 0)",backgroundSize:"24px 24px" }}/>
        <div style={{ width:80,height:80,borderRadius:26,background:"rgba(255,255,255,0.15)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:40,margin:"0 auto 14px",border:"3px solid rgba(255,255,255,0.3)" }}>{user?.role==="provider"?"🔨":"👤"}</div>
        <h3 style={{ color:"#fff",margin:"0 0 4px",fontFamily:"'DM Serif Display',Georgia,serif",fontSize:24 }}>{user?.name}</h3>
        <p style={{ color:"rgba(255,255,255,0.7)",margin:"0 0 10px",fontSize:14 }}>{user?.email}</p>
        <Badge text={user?.role==="provider"?"⚙️ Prestataire":"👤 Client"} color="#fff" bg="rgba(255,255,255,0.2)"/>
      </div>
      <div style={{ padding:16,marginTop:-20 }}>
        <Card style={{ marginBottom:16 }}>
          {menuItems.map((item,i)=>(
            <div key={item.label} onClick={item.action} style={{ display:"flex",alignItems:"center",gap:14,padding:"14px 0",borderBottom:i<menuItems.length-1?`1px solid ${T.bg}`:"none",cursor:"pointer" }}>
              <span style={{ fontSize:22 }}>{item.icon}</span>
              <span style={{ flex:1,fontWeight:600,color:T.dark,fontSize:15 }}>{item.label}</span>
              <span style={{ color:"#D1D5DB",fontSize:20 }}>›</span>
            </div>
          ))}
        </Card>
        <Btn onClick={logout} variant="danger" full style={{ background:"#FEF2F2",color:T.danger,border:`2px solid #FECACA` }}>🚪 Se déconnecter</Btn>
        <p style={{ textAlign:"center",color:"#D1D5DB",fontSize:11,marginTop:20 }}>EasyService v1.0.0 MVP · Abidjan, Côte d'Ivoire</p>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: PROVIDER DASHBOARD
// ═══════════════════════════════════════════════════════
function DashboardScreen({ navigate }) {
  const { user } = useApp();
  const toast = useToast();
  const [profile,setProfile]=useState(null);
  const [bookings,setBookings]=useState([]);
  const [tab,setTab]=useState("stats");
  const [editSvcs,setEditSvcs]=useState([]);
  const [editBio,setEditBio]=useState("");
  const [editPrix,setEditPrix]=useState("");
  const [editPhone,setEditPhone]=useState("");
  const [editAvail,setEditAvail]=useState(true);
  const [saved,setSaved]=useState(false);
  const [loading,setLoading]=useState(true);

  useEffect(()=>{
    Promise.all([ProvidersAPI.myProfile(user.id), BookingsAPI.list(user.id,"provider")]).then(([p,b])=>{
      if(p){ setProfile(p); setEditSvcs(p.services||[]); setEditBio(p.bio||""); setEditPrix(p.prix||""); setEditPhone(p.phone||""); setEditAvail(p.available!==false); }
      setBookings(b.reverse()); setLoading(false);
    });
  },[]);

  const saveProfile=async()=>{
    if(!profile) return;
    const updated={...profile,services:editSvcs,bio:editBio,prix:editPrix,phone:editPhone,available:editAvail};
    await ProvidersAPI.save(updated); setProfile(updated);
    setSaved(true); setTimeout(()=>setSaved(false),2500);
    toast.success("Profil mis à jour !");
  };

  const updateBookingStatus=async(id,status)=>{
    await BookingsAPI.updateStatus(id,status);
    setBookings(prev=>prev.map(b=>b.id===id?{...b,status,updatedAt:now()}:b));
    if(status==="confirmed") toast.success("Mission acceptée !");
    if(status==="rejected") toast.info("Mission refusée.");
  };

  if(loading) return <div style={{ minHeight:"100vh",background:T.bg }}><Spinner/></div>;

  const pendingOrders=bookings.filter(b=>b.status==="pending");
  const confirmedOrders=bookings.filter(b=>b.status==="confirmed");
  const completedOrders=bookings.filter(b=>b.status==="completed");
  const totalEarnings=completedOrders.reduce((a,b)=>a+(b.providerAmount||0),0);

  return (
    <div style={{ minHeight:"100vh",background:T.bg,paddingBottom:80 }}>
      <Toast items={toast.items} remove={toast.remove}/>
      <TopBar title="Mon Dashboard" right={profile&&<div onClick={()=>{ setEditAvail(!editAvail); setTimeout(saveProfile,100); }} style={{ display:"flex",alignItems:"center",gap:8,cursor:"pointer" }}><span style={{ fontSize:12,color:"rgba(255,255,255,0.8)" }}>{editAvail?"Disponible":"Indisponible"}</span><div style={{ width:44,height:24,borderRadius:12,background:editAvail?T.success:"#D1D5DB",position:"relative",transition:"background 0.2s" }}><div style={{ width:18,height:18,borderRadius:"50%",background:"#fff",position:"absolute",top:3,left:editAvail?23:3,transition:"left 0.2s",boxShadow:"0 2px 4px rgba(0,0,0,0.2)" }}/></div></div>}/>

      {/* Tabs */}
      <div style={{ display:"flex",background:T.white,borderBottom:`2px solid ${T.bg}` }}>
        {[["stats","📊 Stats"],["orders","📋 Missions"],["services","⚙️ Services"],["earnings","💰 Revenus"]].map(([t,l])=>(
          <button key={t} onClick={()=>setTab(t)} style={{ flex:1,padding:"11px 4px",border:"none",background:"transparent",cursor:"pointer",fontWeight:700,fontSize:11,color:tab===t?T.primary:T.gray,borderBottom:tab===t?`3px solid ${T.primary}`:"3px solid transparent" }}>{l}</button>
        ))}
      </div>

      <div style={{ padding:14 }}>
        {/* ── STATS ── */}
        {tab==="stats"&&(<>
          <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14 }}>
            {[{v:bookings.length,l:"Total missions",i:"📋",c:T.primary},{v:pendingOrders.length,l:"En attente",i:"⏳",c:T.warning},{v:confirmedOrders.length,l:"En cours",i:"🔄",c:T.secondary},{v:completedOrders.length,l:"Terminées",i:"✅",c:T.success},{v:fmtAmt(totalEarnings),l:"Revenus nets",i:"💰",c:T.success},{v:profile?.avgRating||"–",l:"Note moyenne",i:"⭐",c:T.warning}].map(s=>(
              <Card key={s.l} style={{ display:"flex",alignItems:"center",gap:10 }}>
                <div style={{ width:44,height:44,borderRadius:14,background:s.c+"22",display:"flex",alignItems:"center",justifyContent:"center",fontSize:22,flexShrink:0 }}>{s.i}</div>
                <div><p style={{ margin:0,fontWeight:800,fontSize:16,color:s.c }}>{s.v}</p><p style={{ margin:0,fontSize:11,color:T.gray }}>{s.l}</p></div>
              </Card>
            ))}
          </div>
          {/* Edit profile */}
          <Card>
            <h4 style={{ margin:"0 0 14px",color:T.primary }}>Modifier mon profil</h4>
            <Input label="Téléphone" value={editPhone} onChange={e=>setEditPhone(e.target.value)} icon="📞"/>
            <Input label="Tarif indicatif" value={editPrix} onChange={e=>setEditPrix(e.target.value)} icon="💰" placeholder="ex: 5 000 – 20 000 FCFA"/>
            <Textarea label="Bio / Présentation" value={editBio} onChange={e=>setEditBio(e.target.value)} placeholder="Décrivez votre expérience..."/>
            <Btn onClick={saveProfile} full style={{ background:saved?T.success:undefined }}>{saved?"✅ Profil mis à jour !":"Sauvegarder"}</Btn>
          </Card>
        </>)}

        {/* ── ORDERS ── */}
        {tab==="orders"&&(<>
          {pendingOrders.length>0&&(<>
            <h4 style={{ color:T.dark,margin:"0 0 10px",fontFamily:"'DM Serif Display',Georgia,serif" }}>⏳ Nouvelles demandes ({pendingOrders.length})</h4>
            {pendingOrders.map(b=>(
              <Card key={b.id} style={{ marginBottom:12,border:`2px solid ${T.warning}` }}>
                <p style={{ margin:"0 0 4px",fontWeight:700,color:T.dark,fontSize:15 }}>{b.service}</p>
                <p style={{ margin:"0 0 8px",fontSize:13,color:T.gray }}>👤 {b.clientName} · 📅 {fmt(b.date)}</p>
                {b.amount>0&&<p style={{ margin:"0 0 10px",fontSize:13,color:T.gray }}>💰 {fmtAmt(b.amount)} (net: {fmtAmt(b.providerAmount||0)})</p>}
                {b.note&&<p style={{ margin:"0 0 10px",fontSize:12,color:T.gray,fontStyle:"italic" }}>{b.note}</p>}
                <div style={{ display:"flex",gap:8 }}>
                  <Btn onClick={()=>updateBookingStatus(b.id,"confirmed")} full>✅ Accepter</Btn>
                  <Btn onClick={()=>updateBookingStatus(b.id,"rejected")} variant="outline" full style={{ color:T.danger,borderColor:T.danger }}>❌ Refuser</Btn>
                </div>
              </Card>
            ))}
          </>)}
          {bookings.filter(b=>b.status!=="pending").map(b=>(
            <Card key={b.id} style={{ marginBottom:10 }}>
              <div style={{ display:"flex",justifyContent:"space-between",alignItems:"flex-start" }}>
                <div><p style={{ margin:"0 0 2px",fontWeight:700,color:T.dark,fontSize:14 }}>{b.service}</p><p style={{ margin:0,fontSize:12,color:T.gray }}>👤 {b.clientName} · {fmt(b.date)}</p></div>
                <span style={{ background:STATUS_COLORS[b.status]+"22",color:STATUS_COLORS[b.status],borderRadius:8,padding:"3px 9px",fontSize:11,fontWeight:700 }}>{STATUS_LABELS[b.status]}</span>
              </div>
              {b.status==="confirmed"&&(
                <Btn onClick={()=>updateBookingStatus(b.id,"completed")} size="sm" style={{ marginTop:10,background:T.success }}>Marquer terminé</Btn>
              )}
            </Card>
          ))}
          {bookings.length===0&&<div style={{ textAlign:"center",padding:"32px 0" }}><div style={{ fontSize:48 }}>📋</div><p style={{ color:T.gray,marginTop:10 }}>Aucune mission reçue.</p></div>}
        </>)}

        {/* ── SERVICES ── */}
        {tab==="services"&&profile&&(
          <Card>
            <h4 style={{ margin:"0 0 6px",color:T.primary }}>Mes services</h4>
            <p style={{ fontSize:13,color:T.gray,margin:"0 0 14px" }}>Sélectionnez les services que vous proposez :</p>
            <div style={{ display:"flex",flexDirection:"column",gap:8 }}>
              {(SERVICES_BY_CAT[profile.category]||[]).map(s=>{
                const active=editSvcs.includes(s);
                return <div key={s} onClick={()=>{ setEditSvcs(p=>p.includes(s)?p.filter(x=>x!==s):[...p,s]); setSaved(false); }} style={{ display:"flex",alignItems:"center",gap:12,padding:"12px 14px",borderRadius:T.radius,border:`2px solid ${active?T.primary:T.border}`,cursor:"pointer",background:active?T.primary+"11":"#fff",transition:"all 0.15s" }}>
                  <div style={{ width:22,height:22,borderRadius:7,background:active?T.primary:T.bg,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0 }}>{active&&<span style={{ color:"#fff",fontSize:13,fontWeight:800 }}>✓</span>}</div>
                  <span style={{ fontSize:14,fontWeight:600,color:active?T.primary:T.gray }}>{s}</span>
                </div>;
              })}
            </div>
            <Btn onClick={saveProfile} full style={{ marginTop:16,background:saved?T.success:undefined }}>{saved?"✅ Services sauvegardés !":"Enregistrer"}</Btn>
          </Card>
        )}

        {/* ── EARNINGS ── */}
        {tab==="earnings"&&(
          <>
            <div style={{ display:"grid",gridTemplateColumns:"1fr 1fr",gap:10,marginBottom:14 }}>
              {[{v:fmtAmt(totalEarnings),l:"Revenus totaux",i:"💰",c:T.success},{v:fmtAmt(profile?.pendingEarnings||0),l:"En attente",i:"⏳",c:T.warning}].map(s=>(
                <Card key={s.l} style={{ textAlign:"center",background:`linear-gradient(135deg,${s.c}11,${s.c}22)` }}>
                  <p style={{ margin:0,fontSize:30 }}>{s.i}</p>
                  <p style={{ margin:"6px 0 2px",fontWeight:800,fontSize:15,color:s.c }}>{s.v}</p>
                  <p style={{ margin:0,fontSize:11,color:T.gray }}>{s.l}</p>
                </Card>
              ))}
            </div>
            <Card>
              <h4 style={{ margin:"0 0 12px",color:T.primary }}>💸 Retrait des fonds</h4>
              <p style={{ fontSize:13,color:T.gray,marginBottom:14 }}>Fonctionnalité disponible bientôt. Vous pourrez retirer vos revenus via Wave, Orange Money ou MTN MoMo.</p>
              <Btn full disabled>Retrait (bientôt disponible)</Btn>
            </Card>
            {completedOrders.map(b=>(
              <Card key={b.id} style={{ marginBottom:10,display:"flex",justifyContent:"space-between",alignItems:"center" }}>
                <div><p style={{ margin:"0 0 2px",fontWeight:600,color:T.dark,fontSize:14 }}>{b.service}</p><p style={{ margin:0,fontSize:11,color:T.gray }}>{fmt(b.date)}</p></div>
                <div style={{ textAlign:"right" }}><p style={{ margin:0,fontWeight:700,color:T.success,fontSize:15 }}>+{fmtAmt(b.providerAmount||0)}</p><p style={{ margin:0,fontSize:10,color:T.gray }}>Commission: {fmtAmt(b.commission||0)}</p></div>
              </Card>
            ))}
          </>
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  SCREEN: SUPPORT
// ═══════════════════════════════════════════════════════
function SupportScreen({ navigate }) {
  const [msg,setMsg]=useState("");
  const [sent,setSent]=useState(false);
  return (
    <div style={{ minHeight:"100vh",background:T.bg,paddingBottom:80 }}>
      <TopBar title="Aide & Support" onBack={()=>navigate("profile")}/>
      <div style={{ padding:16 }}>
        <Card style={{ marginBottom:14 }}>
          <h4 style={{ margin:"0 0 14px",color:T.primary }}>📞 Nous contacter</h4>
          {[{i:"📱",l:"WhatsApp Support",v:"+225 07 00 00 00"},{i:"📧",l:"Email",v:"support@easyservice.ci"},{i:"⏰",l:"Horaires",v:"Lun–Sam 8h–20h"}].map(r=>(
            <div key={r.l} style={{ display:"flex",gap:12,padding:"10px 0",borderBottom:`1px solid ${T.bg}` }}>
              <span style={{ fontSize:22 }}>{r.i}</span>
              <div><p style={{ margin:0,fontSize:12,color:T.gray }}>{r.l}</p><p style={{ margin:0,fontWeight:600,color:T.dark }}>{r.v}</p></div>
            </div>
          ))}
        </Card>
        <Card>
          <h4 style={{ margin:"0 0 12px",color:T.primary }}>💬 Envoyer un message</h4>
          <Textarea value={msg} onChange={e=>setMsg(e.target.value)} placeholder="Décrivez votre problème..." rows={4}/>
          {sent?<p style={{ color:T.success,fontWeight:600 }}>✅ Message envoyé ! Nous répondrons sous 24h.</p>:<Btn onClick={()=>{ if(msg.trim()){ setSent(true); } }} disabled={!msg.trim()} full>Envoyer →</Btn>}
        </Card>
        <Card style={{ marginTop:14 }}>
          <h4 style={{ margin:"0 0 12px",color:T.primary }}>❓ FAQ</h4>
          {[["Comment réserver un prestataire ?","Trouvez un prestataire, cliquez sur son profil, puis sur 'Réserver'."],["Comment payer ?","Nous acceptons Wave, Orange Money, MTN MoMo et carte bancaire."],["Comment laisser un avis ?","Après votre réservation, retournez sur le profil du prestataire."],["Puis-je annuler ?","Oui, contactez le support dans les 2h suivant la réservation."]].map(([q,a],i,arr)=>(
            <div key={q} style={{ padding:"12px 0",borderBottom:i<arr.length-1?`1px solid ${T.bg}`:"none" }}>
              <p style={{ margin:"0 0 4px",fontWeight:700,color:T.dark,fontSize:14 }}>{q}</p>
              <p style={{ margin:0,fontSize:13,color:T.gray,lineHeight:1.6 }}>{a}</p>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════
//  APP ROOT
// ═══════════════════════════════════════════════════════
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display&family=DM+Sans:wght@400;500;600;700&display=swap');
  *{box-sizing:border-box;margin:0;padding:0;}
  body{font-family:'DM Sans',sans-serif;background:#F3F4F6;}
  input,select,textarea,button{font-family:'DM Sans',sans-serif;}
  select option{color:#111;background:#fff;}
  @keyframes popIn{from{transform:scale(0.7);opacity:0}to{transform:scale(1);opacity:1}}
  @keyframes bounce{0%,100%{transform:translateY(0)}50%{transform:translateY(-10px)}}
  @keyframes spin{to{transform:rotate(360deg)}}
  @keyframes slideIn{from{transform:translateX(40px);opacity:0}to{transform:translateX(0);opacity:1}}
  ::-webkit-scrollbar{width:3px;height:3px}
  ::-webkit-scrollbar-thumb{background:#E5E7EB;border-radius:4px}
  input:focus,select:focus,textarea:focus{border-color:#1A56DB!important;box-shadow:0 0 0 3px rgba(26,86,219,0.1)}
`;

const FIRST_VISIT_KEY = "es_first_visit";

export default function App() {
  const [screen, setScreen]    = useState("splash");
  const [sData,  setSData]     = useState({});
  const [user,   setUser]      = useState(()=>AuthAPI.session());
  const toast                  = useToast();

  const navigate = useCallback((to, data={}) => { setScreen(to); setSData(data); window.scrollTo(0,0); }, []);

  const login  = u => { setUser(u); navigate("home"); };
  const logout = () => { AuthAPI.logout(); setUser(null); navigate("auth"); };

  const ctx = { user, login, logout, navigate, toast };

  const showNav   = !["splash","onboarding","auth"].includes(screen) && user;
  const pb        = showNav ? 72 : 0;

  return (
    <AppCtx.Provider value={ctx}>
      <div style={{ maxWidth:430, margin:"0 auto", minHeight:"100vh", position:"relative", background:T.bg, boxShadow:"0 0 80px rgba(0,0,0,0.12)" }}>
        <style>{CSS}</style>
        <Toast items={toast.items} remove={toast.remove}/>
        <div style={{ paddingBottom:pb }}>
          {screen==="splash"       && <SplashScreen onDone={()=>{ const fv=!localStorage.getItem(FIRST_VISIT_KEY); if(fv){ localStorage.setItem(FIRST_VISIT_KEY,"1"); navigate("onboarding"); } else navigate(user?"home":"auth"); }}/>}
          {screen==="onboarding"   && <OnboardingScreen onDone={()=>navigate(user?"home":"auth")}/>}
          {screen==="auth"         && !user && <AuthScreen onLogin={login}/>}
          {screen==="home"         && user && <HomeScreen navigate={navigate}/>}
          {screen==="category"     && <CategoryScreen category={sData.category} initQuartier={sData.quartier} navigate={navigate}/>}
          {screen==="allproviders" && <CategoryScreen category="" initQuartier="" navigate={navigate}/>}
          {screen==="detail"       && sData.provider && <DetailScreen providerInit={sData.provider} from={sData.from} fromData={sData.fromData} navigate={navigate}/>}
          {screen==="bookings"     && user && <BookingsScreen navigate={navigate}/>}
          {screen==="notifications"&& user && <NotificationsScreen navigate={navigate}/>}
          {screen==="profile"      && user && <ProfileScreen navigate={navigate}/>}
          {screen==="dashboard"    && user && <DashboardScreen navigate={navigate}/>}
          {screen==="support"      && <SupportScreen navigate={navigate}/>}
        </div>
        {showNav && <BottomNav screen={screen} role={user?.role} navigate={navigate}/>}
      </div>
    </AppCtx.Provider>
  );
}
