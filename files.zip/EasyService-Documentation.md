# EasyService — Documentation Technique Complète
## Plateforme de services à domicile · Abidjan, Côte d'Ivoire
**Version :** 1.0.0 MVP  |  **Date :** 2025  |  **Statut :** Prêt à développer

---

## 📁 STRUCTURE DES DOSSIERS

```
easyservice/
├── frontend/                    # Application React / React Native
│   ├── src/
│   │   ├── App.jsx              ← Fichier principal (fourni)
│   │   ├── screens/             # Chaque écran = 1 fichier
│   │   │   ├── SplashScreen.jsx
│   │   │   ├── OnboardingScreen.jsx
│   │   │   ├── AuthScreen.jsx
│   │   │   ├── HomeScreen.jsx
│   │   │   ├── CategoryScreen.jsx
│   │   │   ├── DetailScreen.jsx
│   │   │   ├── BookingsScreen.jsx
│   │   │   ├── DashboardScreen.jsx
│   │   │   ├── ProfileScreen.jsx
│   │   │   ├── NotificationsScreen.jsx
│   │   │   └── SupportScreen.jsx
│   │   ├── components/          # Composants réutilisables
│   │   │   ├── Btn.jsx
│   │   │   ├── Input.jsx
│   │   │   ├── Card.jsx
│   │   │   ├── TopBar.jsx
│   │   │   ├── BottomNav.jsx
│   │   │   ├── ProviderCard.jsx
│   │   │   ├── StarDisplay.jsx
│   │   │   ├── StarPicker.jsx
│   │   │   ├── Toast.jsx
│   │   │   └── Spinner.jsx
│   │   ├── api/                 # Couche API (fetch)
│   │   │   ├── auth.api.js
│   │   │   ├── providers.api.js
│   │   │   ├── bookings.api.js
│   │   │   ├── payments.api.js
│   │   │   └── reviews.api.js
│   │   ├── hooks/               # React Hooks custom
│   │   │   ├── useAuth.js
│   │   │   ├── useProviders.js
│   │   │   ├── useToast.js
│   │   │   └── useGeolocation.js
│   │   ├── store/               # État global (Zustand)
│   │   │   ├── authStore.js
│   │   │   ├── providerStore.js
│   │   │   └── bookingStore.js
│   │   └── utils/
│   │       ├── formatters.js
│   │       ├── validators.js
│   │       └── constants.js
│   ├── public/
│   ├── package.json
│   └── .env.example
│
├── backend/                     # API Node.js + Express
│   ├── src/
│   │   ├── server.js            ← Fichier principal (fourni)
│   │   ├── routes/
│   │   │   ├── auth.js          # POST /register, /login, /refresh
│   │   │   ├── users.js         # GET/PUT /users/:id
│   │   │   ├── providers.js     # GET /providers, PUT /:id
│   │   │   ├── services.js      # GET /services (catégories)
│   │   │   ├── bookings.js      # POST/GET /bookings
│   │   │   ├── reviews.js       # POST /reviews
│   │   │   ├── payments.js      # POST /payments/initiate, /webhook
│   │   │   ├── notifications.js # GET /notifications
│   │   │   ├── admin.js         # Admin back-office
│   │   │   └── uploads.js       # Upload photos
│   │   ├── controllers/
│   │   ├── models/
│   │   ├── middleware/
│   │   │   ├── auth.js          # JWT guard
│   │   │   ├── upload.js        # Multer config
│   │   │   └── rateLimit.js
│   │   └── services/
│   │       ├── emailService.js  # Nodemailer
│   │       ├── smsService.js    # SMS (Twilio/Africa's Talking)
│   │       ├── pushService.js   # Firebase FCM
│   │       ├── waveService.js   # Wave CI integration
│   │       └── storageService.js # AWS S3 / Cloudinary
│   ├── prisma/
│   │   ├── schema.prisma        ← Schéma DB complet (fourni)
│   │   └── seed.js
│   ├── package.json
│   └── .env.example
│
├── admin/                       # Dashboard administrateur
│   └── (React + Recharts)
│
└── docs/
    └── README.md                ← Ce fichier
```

---

## 🛠️ STACK TECHNOLOGIQUE

| Couche         | Technologie           | Justification |
|----------------|-----------------------|---------------|
| Frontend       | React (Web MVP)       | Déploiement rapide, testable mobile |
| Mobile         | React Native (v2)     | iOS + Android depuis le même code |
| Backend        | Node.js + Express     | Rapide, léger, idéal API REST |
| ORM            | Prisma                | Type-safe, migrations auto |
| Base de données| PostgreSQL            | Relationnel, fiable, scalable |
| Auth           | JWT + bcrypt          | Sécurisé, stateless |
| Stockage       | AWS S3 / Cloudinary   | Photos prestataires |
| Push notifs    | Firebase FCM          | iOS + Android |
| Paiement       | Wave + CinetPay       | Priorité marché CI |
| Hébergement    | Railway / Render      | Gratuit MVP → DigitalOcean |
| CDN            | Cloudflare            | Performance Afrique |

---

## 🔌 API ENDPOINTS

### Authentification
```
POST   /api/auth/register        Inscription client ou prestataire
POST   /api/auth/login           Connexion
POST   /api/auth/refresh         Renouveler le token
GET    /api/auth/me              Profil connecté
POST   /api/auth/logout          Déconnexion
POST   /api/auth/forgot-password Mot de passe oublié
POST   /api/auth/reset-password  Réinitialiser mot de passe
```

### Prestataires
```
GET    /api/providers             Liste (filtres: category, quartier, search, available)
GET    /api/providers/:id         Détail prestataire
PUT    /api/providers/:id         Mettre à jour profil
PATCH  /api/providers/:id/availability  Toggle disponibilité
GET    /api/providers/:id/reviews Avis d'un prestataire
POST   /api/providers/:id/upload-id     Upload pièce d'identité
```

### Réservations
```
POST   /api/bookings              Créer réservation
GET    /api/bookings              Liste (role=client|provider, status, page)
GET    /api/bookings/:id          Détail réservation
PATCH  /api/bookings/:id/status   Changer statut (confirmed|rejected|completed|cancelled)
```

### Paiements
```
POST   /api/payments/initiate     Initier paiement
POST   /api/payments/webhook      Callback paiement (Wave/Orange/MTN)
GET    /api/payments/history      Historique transactions
POST   /api/payments/withdraw     Retrait prestataire
```

### Avis
```
POST   /api/reviews               Créer avis
GET    /api/reviews/provider/:id  Avis d'un prestataire
```

### Admin
```
GET    /api/admin/stats           Statistiques globales
GET    /api/admin/providers       Liste prestataires (validation)
PATCH  /api/admin/providers/:id/verify  Valider/refuser prestataire
PATCH  /api/admin/users/:id/suspend     Suspendre compte
GET    /api/admin/transactions    Toutes les transactions
GET    /api/admin/disputes        Litiges
PATCH  /api/admin/disputes/:id    Résoudre litige
```

---

## 💳 INTÉGRATION PAIEMENT

### 1. Wave Côte d'Ivoire
```javascript
// Documentation: https://wave.com/en/documentation/
const createCheckout = async ({ amount, reference }) => {
  const res = await fetch("https://api.wave.com/v1/checkout/sessions", {
    method: "POST",
    headers: { Authorization: `Bearer ${WAVE_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      amount: String(amount),
      currency: "XOF",
      client_reference: reference,
      success_url: `${APP_URL}/booking/${reference}/success`,
      error_url:   `${APP_URL}/booking/${reference}/error`,
    })
  });
  return res.json(); // { id, wave_launch_url }
};
```

### 2. Orange Money / CinetPay
```javascript
// SDK: npm install cinetpay-sdk
const cinetpay = require("cinetpay-sdk");
const payment = await cinetpay.initPayment({
  amount: 15000, currency: "XOF",
  transaction_id: bookingId,
  customer_phone_number: "+225XXXXXXXX",
  notify_url: `${API_URL}/api/payments/webhook`,
});
```

### 3. MTN MoMo
```javascript
// Documentation: https://momodeveloper.mtn.com/
// Étapes: créer API user → générer API Key → request to pay
```

---

## 🔐 SÉCURITÉ

| Mesure                    | Implémentation |
|---------------------------|----------------|
| Mots de passe             | bcrypt (salt=12) |
| Tokens                    | JWT HS256, expire 30j |
| Rate limiting             | 100 req/min par IP |
| Upload fichiers           | Validation MIME, max 5MB |
| Données sensibles         | Variables .env uniquement |
| CORS                      | Origines whitelistées |
| SQL Injection             | Prisma ORM (paramétré) |
| XSS                       | helmet.js headers |
| Paiements                 | HTTPS only, webhook signature |
| Pièces d'identité        | Stockage privé S3, accès signé |

---

## 📱 PAGES DE L'APPLICATION

| N° | Page              | Rôle     | Statut |
|----|-------------------|----------|--------|
| 1  | Splash Screen     | Tous     | ✅ Codé |
| 2  | Onboarding (3 slides)| Tous  | ✅ Codé |
| 3  | Login / Register  | Tous     | ✅ Codé |
| 4  | Home + Catégories | Client   | ✅ Codé |
| 5  | Liste prestataires| Client   | ✅ Codé |
| 6  | Profil prestataire| Client   | ✅ Codé |
| 7  | Réservation       | Client   | ✅ Codé |
| 8  | Paiement (simulé) | Client   | ✅ Codé |
| 9  | Historique réservations | Tous | ✅ Codé |
| 10 | Profil utilisateur| Tous     | ✅ Codé |
| 11 | Dashboard prestataire | Prestataire | ✅ Codé |
| 12 | Notifications     | Tous     | ✅ Codé |
| 13 | Support           | Tous     | ✅ Codé |
| 14 | Mode urgence      | Client   | ✅ Codé |
| 15 | Admin back-office | Admin    | 🔧 Backend prêt |
| 16 | Suivi temps réel  | Tous     | 🔜 V2 |
| 17 | Chat intégré      | Tous     | 🔜 V2 |

---

## 🚀 DÉPLOIEMENT — STRATÉGIE

### Phase 1 — MVP (Semaine 1-4)
```bash
# Frontend — Vercel (gratuit)
npm run build && vercel deploy

# Backend — Railway (gratuit jusqu'à $5/mois)
railway init && railway up

# Base de données — Railway PostgreSQL
railway add postgresql
```

### Phase 2 — Beta (Mois 2-3)
```
Frontend : Vercel Pro          ~$20/mois
Backend  : DigitalOcean Droplet 2GB  ~$18/mois
DB       : DigitalOcean PostgreSQL   ~$15/mois
CDN      : Cloudflare Free
Stockage : AWS S3 + CloudFront ~$5/mois
```

### Phase 3 — Production
```
AWS EC2 t3.medium x2 (load balancer)
AWS RDS PostgreSQL Multi-AZ
AWS S3 + CloudFront
Redis pour cache + sessions
```

### Variables d'environnement (.env)
```env
# Serveur
NODE_ENV=production
PORT=3001
FRONTEND_URL=https://easyservice.ci

# Base de données
DATABASE_URL=postgresql://user:pass@host:5432/easyservice

# JWT
JWT_SECRET=super_secret_key_change_in_prod_min_32_chars
JWT_EXPIRE=30d

# Paiements
WAVE_API_KEY=wv_...
CINETPAY_API_KEY=...
CINETPAY_SITE_ID=...
MTN_MOMO_API_USER=...
MTN_MOMO_API_KEY=...
STRIPE_SECRET_KEY=sk_...

# Firebase (Push notifications)
FIREBASE_PROJECT_ID=...
FIREBASE_PRIVATE_KEY=...
FIREBASE_CLIENT_EMAIL=...

# Stockage
AWS_ACCESS_KEY_ID=...
AWS_SECRET_ACCESS_KEY=...
AWS_BUCKET=easyservice-media
CLOUDINARY_URL=cloudinary://...

# Email
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=noreply@easyservice.ci
SMTP_PASS=...

# SMS
AFRICAS_TALKING_API_KEY=...
AFRICAS_TALKING_USERNAME=easyservice
```

---

## 💡 FONCTIONNALITÉS AVANCÉES (V2 Roadmap)

| Fonctionnalité        | Description | Priorité |
|-----------------------|-------------|----------|
| Géolocalisation Maps  | Google Maps SDK, prestataires proches | 🔴 Haute |
| Chat temps réel       | Socket.io ou Firebase Realtime | 🔴 Haute |
| Push notifications    | Firebase FCM (iOS + Android) | 🔴 Haute |
| Suivi GPS             | Localisation prestataire en temps réel | 🟡 Moyenne |
| Code promo            | Système de réductions | 🟡 Moyenne |
| Parrainage            | Référral avec bonus | 🟡 Moyenne |
| Abonnement premium    | Prestataires mis en avant | 🟡 Moyenne |
| App mobile native     | React Native | 🔴 Haute |
| Micro-crédit          | Avance sur revenus prestataires | 🟢 Long terme |
| Assurance service     | Garantie interventions | 🟢 Long terme |
| Extension UEMOA       | Sénégal, Mali, Burkina | 🟢 Long terme |

---

## 📊 MODÈLE ÉCONOMIQUE

| Revenus              | Détails |
|----------------------|---------|
| Commission (10%)     | Sur chaque transaction complétée |
| Abonnement Premium   | 5 000 FCFA/mois par prestataire (mise en avant) |
| Publicité            | Bannières dans l'app |
| Mise en avant        | Prestataire sponsorisé en top liste |

**Projection Year 1 :**
- 500 prestataires actifs × commission moyenne 2 000 FCFA/semaine
- **= 4 000 000 FCFA/mois** en commissions seules

---

## 📦 PACKAGE.JSON

### Frontend
```json
{
  "name": "easyservice-frontend",
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "zustand": "^4.4.0",
    "axios": "^1.6.0"
  },
  "devDependencies": {
    "vite": "^5.0.0",
    "@vitejs/plugin-react": "^4.2.0"
  }
}
```

### Backend
```json
{
  "name": "easyservice-api",
  "dependencies": {
    "express": "^4.18.2",
    "cors": "^2.8.5",
    "helmet": "^7.1.0",
    "bcryptjs": "^2.4.3",
    "jsonwebtoken": "^9.0.2",
    "@prisma/client": "^5.6.0",
    "multer": "^1.4.5",
    "nodemailer": "^6.9.7",
    "express-validator": "^7.0.1",
    "morgan": "^1.10.0",
    "dotenv": "^16.3.1",
    "express-rate-limit": "^7.1.5",
    "firebase-admin": "^12.0.0",
    "aws-sdk": "^2.1490.0"
  },
  "devDependencies": {
    "prisma": "^5.6.0",
    "nodemon": "^3.0.2"
  }
}
```

---

*EasyService — Plateforme ivoirienne de services à domicile*
*Conçu pour dominer le marché d'Abidjan, puis l'Afrique de l'Ouest.*
