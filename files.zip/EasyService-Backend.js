/**
 * EasyService — Backend API
 * Node.js + Express + Prisma (PostgreSQL) + JWT
 * 
 * Installation:
 *   npm install express cors helmet bcryptjs jsonwebtoken
 *               prisma @prisma/client multer nodemailer
 *               stripe dotenv express-validator morgan
 */

// ── server.js ────────────────────────────────────────────────
const express  = require("express");
const cors     = require("cors");
const helmet   = require("helmet");
const morgan   = require("morgan");
require("dotenv").config();

const app = express();
app.use(cors({ origin: process.env.FRONTEND_URL || "*" }));
app.use(helmet());
app.use(morgan("dev"));
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

// ── Routes ────────────────────────────────────────────────────
app.use("/api/auth",          require("./routes/auth"));
app.use("/api/users",         require("./routes/users"));
app.use("/api/providers",     require("./routes/providers"));
app.use("/api/services",      require("./routes/services"));
app.use("/api/bookings",      require("./routes/bookings"));
app.use("/api/reviews",       require("./routes/reviews"));
app.use("/api/payments",      require("./routes/payments"));
app.use("/api/notifications", require("./routes/notifications"));
app.use("/api/admin",         require("./routes/admin"));
app.use("/api/uploads",       require("./routes/uploads"));

app.get("/api/health", (req, res) => res.json({ status: "ok", version: "1.0.0", env: process.env.NODE_ENV }));

// ── Global error handler ──────────────────────────────────────
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(err.status || 500).json({ error: err.message || "Erreur interne du serveur" });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`✅ EasyService API démarrée sur le port ${PORT}`));

module.exports = app;


// ════════════════════════════════════════════════════════════════
//  middleware/auth.js — JWT Authentication
// ════════════════════════════════════════════════════════════════
/*
const jwt   = require("jsonwebtoken");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

exports.protect = async (req, res, next) => {
  const token = req.headers.authorization?.startsWith("Bearer ")
    ? req.headers.authorization.split(" ")[1] : null;
  if (!token) return res.status(401).json({ error: "Non autorisé" });
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = await prisma.user.findUnique({ where: { id: decoded.id }, select: { id:true, email:true, name:true, role:true, active:true } });
    if (!req.user?.active) return res.status(401).json({ error: "Compte suspendu" });
    next();
  } catch {
    res.status(401).json({ error: "Token invalide ou expiré" });
  }
};

exports.restrictTo = (...roles) => (req, res, next) => {
  if (!roles.includes(req.user.role)) return res.status(403).json({ error: "Accès refusé" });
  next();
};
*/


// ════════════════════════════════════════════════════════════════
//  routes/auth.js — Authentication routes
// ════════════════════════════════════════════════════════════════
/*
const router  = require("express").Router();
const bcrypt  = require("bcryptjs");
const jwt     = require("jsonwebtoken");
const { body, validationResult } = require("express-validator");
const { PrismaClient } = require("@prisma/client");
const prisma  = new PrismaClient();

const genToken = id => jwt.sign({ id }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRE || "30d" });

// POST /api/auth/register
router.post("/register", [
  body("name").notEmpty().withMessage("Nom requis"),
  body("email").isEmail().withMessage("Email invalide"),
  body("password").isLength({ min:6 }).withMessage("Minimum 6 caractères"),
  body("role").isIn(["client","provider"]).withMessage("Rôle invalide"),
], async (req, res, next) => {
  try {
    const errors = validationResult(req);
    if (!errors.isEmpty()) return res.status(400).json({ errors: errors.array() });

    const { name, email, password, phone, role } = req.body;
    const exists = await prisma.user.findUnique({ where: { email } });
    if (exists) return res.status(409).json({ error: "Email déjà utilisé" });

    const hashedPwd = await bcrypt.hash(password, 12);
    const user = await prisma.user.create({ data: { name, email, password: hashedPwd, phone: phone||null, role, active:true } });

    if (role === "provider") {
      await prisma.provider.create({ data: { userId:user.id, name, phone:phone||null, category:req.body.category||"", quartier:req.body.quartier||"", bio:req.body.bio||"", prix:req.body.prix||"", available:true, verified:false } });
    }

    const token = genToken(user.id);
    res.status(201).json({ token, user: { id:user.id, name, email, role } });
  } catch(e) { next(e); }
});

// POST /api/auth/login
router.post("/login", async (req, res, next) => {
  try {
    const { email, password } = req.body;
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ error: "Email ou mot de passe incorrect" });
    if (!user.active) return res.status(401).json({ error: "Compte suspendu" });
    const token = genToken(user.id);
    res.json({ token, user: { id:user.id, name:user.name, email, role:user.role, phone:user.phone } });
  } catch(e) { next(e); }
});

// GET /api/auth/me
router.get("/me", protect, async (req, res) => res.json(req.user));

// POST /api/auth/refresh
router.post("/refresh", protect, (req, res) => {
  const token = genToken(req.user.id);
  res.json({ token });
});

module.exports = router;
*/


// ════════════════════════════════════════════════════════════════
//  routes/providers.js — Providers CRUD
// ════════════════════════════════════════════════════════════════
/*
const router = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();
const { protect, restrictTo } = require("../middleware/auth");

// GET /api/providers — list with filters
router.get("/", async (req, res, next) => {
  try {
    const { category, quartier, search, available, page=1, limit=20 } = req.query;
    const where = {
      ...(category  && { category }),
      ...(quartier  && { quartier }),
      ...(available && { available: available==="true" }),
      ...(search    && { OR: [
        { name: { contains: search, mode:"insensitive" } },
        { bio:  { contains: search, mode:"insensitive" } },
        { services: { has: search } },
      ]}),
    };
    const [providers, total] = await Promise.all([
      prisma.provider.findMany({ where, include: { reviews: { select:{ rating:true } } }, skip:(page-1)*limit, take:+limit, orderBy:{ avgRating:"desc" } }),
      prisma.provider.count({ where }),
    ]);
    res.json({ providers, total, page:+page, pages:Math.ceil(total/limit) });
  } catch(e) { next(e); }
});

// GET /api/providers/:id
router.get("/:id", async (req, res, next) => {
  try {
    const provider = await prisma.provider.findUnique({ where:{ id:req.params.id }, include:{ reviews: true, user:{ select:{ createdAt:true } } } });
    if (!provider) return res.status(404).json({ error: "Prestataire non trouvé" });
    res.json(provider);
  } catch(e) { next(e); }
});

// PUT /api/providers/:id — update own profile
router.put("/:id", protect, async (req, res, next) => {
  try {
    const { services, bio, prix, phone, available, quartier, photoUrl } = req.body;
    const provider = await prisma.provider.update({
      where: { id:req.params.id },
      data: { services, bio, prix, phone, available, quartier, photoUrl, updatedAt:new Date() }
    });
    res.json(provider);
  } catch(e) { next(e); }
});

module.exports = router;
*/


// ════════════════════════════════════════════════════════════════
//  routes/bookings.js — Booking management
// ════════════════════════════════════════════════════════════════
/*
const router   = require("express").Router();
const { PrismaClient } = require("@prisma/client");
const prisma   = new PrismaClient();
const { protect } = require("../middleware/auth");
const COMMISSION = 0.10;

// POST /api/bookings — create booking
router.post("/", protect, async (req, res, next) => {
  try {
    const { providerId, service, date, time, amount, note, payMethod } = req.body;
    const commission    = Math.round((amount||0) * COMMISSION);
    const providerAmount= (amount||0) - commission;
    const booking = await prisma.booking.create({ data: {
      clientId: req.user.id, providerId, service, scheduledDate:new Date(date),
      scheduledTime:time, amount:+amount||0, commission, providerAmount,
      note, payMethod, status:"pending"
    }});
    // TODO: send push notification to provider
    res.status(201).json(booking);
  } catch(e) { next(e); }
});

// GET /api/bookings?role=client|provider
router.get("/", protect, async (req, res, next) => {
  try {
    const { role="client", status, page=1, limit=20 } = req.query;
    const where = {
      ...(role==="client" ? { clientId:req.user.id } : { provider:{ userId:req.user.id } }),
      ...(status && { status }),
    };
    const bookings = await prisma.booking.findMany({ where, include:{ provider:{ select:{ name:true, category:true } }, client:{ select:{ name:true } } }, skip:(page-1)*limit, take:+limit, orderBy:{ createdAt:"desc" } });
    res.json(bookings);
  } catch(e) { next(e); }
});

// PATCH /api/bookings/:id/status — update status
router.patch("/:id/status", protect, async (req, res, next) => {
  try {
    const { status } = req.body;
    const allowed = ["confirmed","rejected","completed","cancelled"];
    if (!allowed.includes(status)) return res.status(400).json({ error:"Statut invalide" });
    const booking = await prisma.booking.update({ where:{ id:req.params.id }, data:{ status, updatedAt:new Date() } });
    if (status==="completed") {
      await prisma.provider.update({ where:{ id:booking.providerId }, data:{ earnings:{ increment:booking.providerAmount }, completedOrders:{ increment:1 } } });
    }
    res.json(booking);
  } catch(e) { next(e); }
});

module.exports = router;
*/


// ════════════════════════════════════════════════════════════════
//  routes/payments.js — Payment integration
// ════════════════════════════════════════════════════════════════
/*
const router = require("express").Router();
const { protect } = require("../middleware/auth");

// TODO: Integrate real payment SDKs:
// - Wave CI:    https://wave.com/en/documentation/
// - Orange Money: CinetPay SDK (supports Orange CI)
// - MTN MoMo:   https://momodeveloper.mtn.com/
// - Stripe:     https://stripe.com/docs (cards)

// POST /api/payments/initiate
router.post("/initiate", protect, async (req, res, next) => {
  try {
    const { bookingId, method, amount, phone } = req.body;
    let paymentUrl = null;

    if (method === "wave") {
      // Wave CI — create checkout
      // const wave = require("../services/waveService");
      // paymentUrl = await wave.createCheckout({ amount, reference: bookingId });
      paymentUrl = `https://pay.wave.com/m/EASYSERVICE?amount=${amount}`; // placeholder
    } else if (method === "orange") {
      // CinetPay / Orange Money
      // paymentUrl = await cinetpay.createPayment({ amount, bookingId });
      paymentUrl = "https://cinetpay.com/payment"; // placeholder
    } else if (method === "mtn") {
      // MTN MoMo API
      paymentUrl = "https://mtn.com/momo"; // placeholder
    } else if (method === "card") {
      // Stripe
      // const stripe = require("stripe")(process.env.STRIPE_KEY);
      // const session = await stripe.checkout.sessions.create({...});
      // paymentUrl = session.url;
      paymentUrl = "https://checkout.stripe.com"; // placeholder
    }

    // Save pending transaction
    // await prisma.transaction.create({ data:{ bookingId, method, amount, status:"pending", paymentUrl } });
    res.json({ paymentUrl, status:"pending" });
  } catch(e) { next(e); }
});

// POST /api/payments/webhook — payment confirmation callback
router.post("/webhook", async (req, res) => {
  try {
    const { reference, status } = req.body;
    if (status === "success") {
      // await prisma.booking.update({ where:{ id:reference }, data:{ paymentStatus:"paid" } });
      // await prisma.transaction.update({ where:{ bookingId:reference }, data:{ status:"completed" } });
    }
    res.json({ received: true });
  } catch(e) { res.status(500).send(); }
});

module.exports = router;
*/


// ════════════════════════════════════════════════════════════════
//  routes/admin.js — Admin back-office
// ════════════════════════════════════════════════════════════════
/*
const router = require("express").Router();
const { protect, restrictTo } = require("../middleware/auth");
const { PrismaClient } = require("@prisma/client");
const prisma = new PrismaClient();

router.use(protect, restrictTo("admin"));

// GET /api/admin/stats — dashboard stats
router.get("/stats", async (req, res, next) => {
  try {
    const [users, providers, bookings, revenue] = await Promise.all([
      prisma.user.count(),
      prisma.provider.count(),
      prisma.booking.count(),
      prisma.booking.aggregate({ where:{ status:"completed" }, _sum:{ amount:true, commission:true } }),
    ]);
    const pendingValidation = await prisma.provider.count({ where:{ verified:false } });
    res.json({ totalUsers:users, totalProviders:providers, totalBookings:bookings, totalRevenue:revenue._sum.amount||0, totalCommissions:revenue._sum.commission||0, pendingValidation });
  } catch(e) { next(e); }
});

// PATCH /api/admin/providers/:id/verify
router.patch("/providers/:id/verify", async (req, res, next) => {
  try {
    const { verified } = req.body;
    const provider = await prisma.provider.update({ where:{ id:req.params.id }, data:{ verified } });
    res.json(provider);
  } catch(e) { next(e); }
});

// PATCH /api/admin/users/:id/suspend
router.patch("/users/:id/suspend", async (req, res, next) => {
  try {
    const user = await prisma.user.update({ where:{ id:req.params.id }, data:{ active:false } });
    res.json({ message:"Compte suspendu", userId:user.id });
  } catch(e) { next(e); }
});

// GET /api/admin/transactions
router.get("/transactions", async (req, res, next) => {
  try {
    const transactions = await prisma.booking.findMany({ where:{ status:"completed" }, include:{ client:{ select:{ name:true } }, provider:{ select:{ name:true } } }, orderBy:{ updatedAt:"desc" }, take:100 });
    res.json(transactions);
  } catch(e) { next(e); }
});

module.exports = router;
*/
